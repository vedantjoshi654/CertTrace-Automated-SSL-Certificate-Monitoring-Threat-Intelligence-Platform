"""
CertTrace V3.0 — CLI Entrypoint (Production Threat Hunter)
Usage:
  python main.py                       # Production mode (live certstream + crt.sh hunter)
  python main.py --refresh-allowlist   # Download fresh Tranco Top 1M list
  python main.py --workers N           # Override worker count (default: 8)
  python main.py --api-only            # Start FastAPI only (no ingestor)

Dashboard (separate terminal):
  streamlit run dashboard.py --server.port 8501
"""

import asyncio
import logging
import sys
import os
from pathlib import Path

import click
from rich.console import Console

sys.path.insert(0, os.path.dirname(__file__))
from config import (
    QUEUE_MAXSIZE, WORKER_COUNT, TARGETS_FILE, API_HOST, API_PORT
)
from certtrace.database  import init_db
from certtrace.allowlist import load_allowlist
from certtrace.hunter    import active_osint_hunter
from certtrace.worker    import configure as configure_workers, run_worker_pool
from certtrace.ingestor  import run_live, run_demo

console = Console()

# ── Logging setup ─────────────────────────────────────────────────────────────

def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    fmt   = "%(asctime)s [%(name)-22s] %(levelname)-7s %(message)s"

    # Rotating file handler
    from logging.handlers import RotatingFileHandler
    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)

    file_h = RotatingFileHandler(
        log_dir / "certtrace.log",
        maxBytes=10 * 1024 * 1024,   # 10 MB
        backupCount=5,
        encoding="utf-8",
    )
    file_h.setFormatter(logging.Formatter(fmt))

    stream_h = logging.StreamHandler(sys.stdout)
    stream_h.setFormatter(logging.Formatter(fmt))

    logging.basicConfig(level=level, handlers=[file_h, stream_h])

    # Silence noisy third-party loggers
    for noisy in ("websockets", "asyncio", "aiosqlite", "urllib3", "httpx"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


# ── Protected targets loader ──────────────────────────────────────────────────

def load_protected_targets() -> list[str]:
    targets: list[str] = []
    if TARGETS_FILE.exists():
        with open(TARGETS_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    targets.append(line.lower())
    if not targets:
        console.print("[yellow]⚠  protected_targets.txt is empty or missing — using defaults[/]")
        targets = ["hdfcbank.com", "icicibank.com", "sbi.co.in"]
    return targets


# ── Startup banner ────────────────────────────────────────────────────────────

def print_banner(mode: str, worker_count: int) -> None:
    from rich.panel import Panel
    from rich.text import Text

    title_text = Text()
    title_text.append("CertTrace ", style="bold cyan")
    title_text.append("V3.0", style="bold white")
    title_text.append("  |  SSL Threat Intelligence Platform", style="dim")

    body = (
        f"Mode      : [{'green' if mode == 'live' else 'yellow'}]{mode.upper()}[/]\n"
        f"Workers   : {worker_count}\n"
        f"HTML Dash : http://{API_HOST}:{API_PORT}\n"
        f"Streamlit : http://127.0.0.1:8501  [dim](run in a separate terminal)[/dim]"
    )
    console.print(Panel(body, title=title_text, border_style="cyan", padding=(1, 2)))
    console.rule("[dim cyan]Initialising pipeline...[/dim cyan]")


# ── Main async runner ─────────────────────────────────────────────────────────

async def _run_pipeline(worker_count: int, hunter: bool, demo: bool) -> None:
    """Start the full producer-consumer pipeline (LIVE threat hunting)."""
    queue = asyncio.Queue(maxsize=QUEUE_MAXSIZE)

    # Import broadcast callback from api module (may not be started yet — graceful)
    try:
        from api import broadcast_ioc
    except Exception:
        broadcast_ioc = None

    configure_workers(
        protected_targets=load_protected_targets(),
        broadcast_cb=broadcast_ioc,
    )

    protected_targets = load_protected_targets()

    # Run producer + consumer pool concurrently
    async with asyncio.TaskGroup() as tg:
        if demo:
            tg.create_task(run_demo(queue, protected_targets))
        else:
            tg.create_task(run_live(queue))
        if hunter:
            tg.create_task(active_osint_hunter(queue, protected_targets))
        tg.create_task(run_worker_pool(queue))


async def _run_with_api(worker_count: int, hunter: bool, demo: bool) -> None:
    """Run FastAPI server + live pipeline concurrently."""
    import uvicorn
    from api import app, broadcast_ioc

    configure_workers(
        protected_targets=load_protected_targets(),
        broadcast_cb=broadcast_ioc,
    )

    queue = asyncio.Queue(maxsize=QUEUE_MAXSIZE)

    protected_targets = load_protected_targets()

    server_config = uvicorn.Config(
        app,
        host=API_HOST,
        port=API_PORT,
        log_level="warning",
        access_log=False,
    )
    server = uvicorn.Server(server_config)

    async with asyncio.TaskGroup() as tg:
        tg.create_task(server.serve())
        if demo:
            tg.create_task(run_demo(queue, protected_targets))
        else:
            tg.create_task(run_live(queue))
        if hunter:
            tg.create_task(active_osint_hunter(queue, protected_targets))
        tg.create_task(run_worker_pool(queue))


# ── CLI ────────────────────────────────────────────────────────────────────────

@click.command()
@click.option("--refresh-allowlist",  is_flag=True,  help="Download fresh Tranco Top 1M list then run")
@click.option("--api-only",           is_flag=True,  help="Start FastAPI server only (no ingestor)")
@click.option("--workers",            default=WORKER_COUNT, show_default=True, help="Number of consumer workers")
@click.option("--verbose", "-v",      is_flag=True,  help="Enable DEBUG logging")
@click.option("--no-api",             is_flag=True,  help="Skip the FastAPI server (pipeline only)")
@click.option("--hunter/--no-hunter", default=True, show_default=True, help="Enable the crt.sh OSINT hunter producer")
@click.option("--demo", is_flag=True, help="Demo mode — synthetic certs (offline testing)")
def main(refresh_allowlist, api_only, workers, verbose, no_api, hunter, demo):
    """CertTrace V3.0 — Production Real-Time SSL Certificate Threat Hunter."""
    setup_logging(verbose)

    # Tranco refresh
    if refresh_allowlist:
        console.print("[cyan]↺[/] Refreshing Tranco allowlist…")
        from certtrace.allowlist import refresh_allowlist as do_refresh
        do_refresh()
        console.print("[green]✓[/] Allowlist refreshed.")
        if not api_only:
            return     # Exit after refresh unless other flags set

    print_banner("demo" if demo else "live", workers)

    # Init DB synchronously before async loop
    asyncio.run(_init())

    # Load allowlist into memory
    load_allowlist()

    if api_only:
        import uvicorn
        console.print(f"[cyan]▶[/] Starting FastAPI on http://{API_HOST}:{API_PORT}")
        uvicorn.run("api:app", host=API_HOST, port=API_PORT, log_level="info")
        return

    # Run full stack (LIVE THREAT HUNTING)
    try:
        if no_api:
            asyncio.run(_run_pipeline(workers, hunter, demo))
        else:
            asyncio.run(_run_with_api(workers, hunter, demo))
    except KeyboardInterrupt:
        console.print("\n[yellow]⏹  CertTrace stopped by user.[/]")
    except Exception as exc:
        console.print(f"\n[red]✗ Fatal error: {exc}[/]")
        raise


async def _init():
    await init_db()


if __name__ == "__main__":
    main()
