"""
CertTrace V3.0 — WHOIS Enrichment Module
Queries WHOIS for a domain or IP and returns structured registration data.
Flags newly-registered domains (< 30 days) as a high-risk signal.
"""

import asyncio
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

import whois   # python-whois

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import NEWLY_REGISTERED_DAYS

logger = logging.getLogger("certtrace.whois")


def _to_dt(val) -> Optional[datetime]:
    """Normalise whois date fields (can be list, datetime, or None)."""
    if val is None:
        return None
    if isinstance(val, list):
        val = val[0] if val else None
    if isinstance(val, datetime):
        if val.tzinfo is None:
            val = val.replace(tzinfo=timezone.utc)
        return val
    return None


def _to_str(val) -> str:
    """Normalise whois string fields (can be list, str, or None)."""
    if val is None:
        return "Unknown"
    if isinstance(val, list):
        return ", ".join(str(v) for v in val if v)[:200]
    return str(val)[:200]


async def lookup_whois(target: str) -> dict:
    """
    Perform a WHOIS lookup for a domain or IP.
    Runs in a thread executor to avoid blocking the event loop.
    Returns a structured dict with registration intelligence.
    """
    loop = asyncio.get_event_loop()

    def _query():
        try:
            return whois.whois(target)
        except Exception as e:
            logger.debug(f"[WHOIS] Query failed for {target}: {e}")
            return None

    try:
        w = await asyncio.wait_for(
            loop.run_in_executor(None, _query),
            timeout=12
        )
    except asyncio.TimeoutError:
        logger.warning(f"[WHOIS] Timeout for {target}")
        return _empty_result(target, error="WHOIS timeout")
    except Exception as e:
        return _empty_result(target, error=str(e))

    if w is None:
        return _empty_result(target, error="No WHOIS data returned")

    # Parse dates
    creation  = _to_dt(getattr(w, "creation_date",     None))
    expiry    = _to_dt(getattr(w, "expiration_date",    None))
    updated   = _to_dt(getattr(w, "updated_date",       None))
    now       = datetime.now(timezone.utc)

    # Newly-registered flag
    newly_registered = False
    domain_age_days  = None
    if creation:
        domain_age_days  = (now - creation).days
        newly_registered = domain_age_days < NEWLY_REGISTERED_DAYS

    # Expiry flag
    expiring_soon = False
    if expiry:
        expiring_soon = (expiry - now) < timedelta(days=30)

    # Name servers
    ns_raw = getattr(w, "name_servers", None) or []
    if isinstance(ns_raw, str):
        ns_raw = [ns_raw]
    name_servers = sorted(set(ns.lower() for ns in ns_raw if ns))[:6]

    # DNSSEC
    dnssec = str(getattr(w, "dnssec", "Unknown"))

    # Status
    status_raw = getattr(w, "status", None) or []
    if isinstance(status_raw, str):
        status_raw = [status_raw]
    statuses = [str(s).split(" ")[0] for s in status_raw[:4]]

    result = {
        "target":            target,
        "registrar":         _to_str(getattr(w, "registrar",       None)),
        "registrant_org":    _to_str(getattr(w, "org",             None)),
        "registrant_email":  _to_str(getattr(w, "emails",          None)),
        "registrant_country":_to_str(getattr(w, "country",         None)),
        "creation_date":     creation.isoformat()  if creation else "Unknown",
        "expiry_date":       expiry.isoformat()    if expiry   else "Unknown",
        "updated_date":      updated.isoformat()   if updated  else "Unknown",
        "domain_age_days":   domain_age_days,
        "newly_registered":  newly_registered,
        "expiring_soon":     expiring_soon,
        "name_servers":      name_servers,
        "dnssec":            dnssec,
        "statuses":          statuses,
        "error":             None,
        # Risk signals from WHOIS
        "risk_flags":        _compute_risk_flags(newly_registered, expiring_soon,
                                                  name_servers, dnssec, statuses),
    }

    logger.info(
        f"[WHOIS] {target} | registrar={result['registrar']} "
        f"| age={domain_age_days}d | newly_reg={newly_registered}"
    )
    return result


def _compute_risk_flags(newly_registered, expiring_soon, name_servers, dnssec, statuses) -> list[str]:
    flags = []
    if newly_registered:
        flags.append("Newly Registered Domain (< 30 days)")
    if expiring_soon:
        flags.append("Domain Expiring Soon (< 30 days)")
    if dnssec.lower() in ("unsigned", "no", "unsigned delegation"):
        flags.append("No DNSSEC")
    # Privacy-protected registrants are common in phishing
    if any("privacy" in (ns or "").lower() for ns in name_servers):
        flags.append("Privacy-Protected Name Servers")
    # clientDeleteProhibited / clientTransferProhibited absent → easier to abandon
    locked = any("transferprohibited" in (s or "").lower() for s in statuses)
    if not locked:
        flags.append("No Transfer Lock (easily abandoned)")
    return flags


def _empty_result(target: str, error: str = "") -> dict:
    return {
        "target":             target,
        "registrar":          "Unknown",
        "registrant_org":     "Unknown",
        "registrant_email":   "Unknown",
        "registrant_country": "Unknown",
        "creation_date":      "Unknown",
        "expiry_date":        "Unknown",
        "updated_date":       "Unknown",
        "domain_age_days":    None,
        "newly_registered":   False,
        "expiring_soon":      False,
        "name_servers":       [],
        "dnssec":             "Unknown",
        "statuses":           [],
        "error":              error,
        "risk_flags":         [],
    }
