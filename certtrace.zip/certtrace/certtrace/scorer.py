"""
CertTrace V3.0 — Heuristic Scoring Engine (Fixed)
Uses real Levenshtein.distance() as spec mandates (distance ≤ 2).
Also checks substring containment for compound brand names
(e.g. "hdfcbank-secure" contains "hdfcbank").
"""

import re
import logging
from dataclasses import dataclass, field

import Levenshtein                           # python-Levenshtein (C extension)

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import (
    WEIGHT_BRAND_IMPERSONATION,
    WEIGHT_FINANCIAL_KEYWORDS,
    WEIGHT_DIGIT_SUBSTITUTION,
    WEIGHT_HIGH_RISK_TLD,
    WEIGHT_FREE_CA,
    HIGH_RISK_TLDS,
    FINANCIAL_KEYWORD_PATTERN,
    HOMOGLYPH_PATTERN,
    FREE_CA_PATTERNS,
    LEVENSHTEIN_MAX_DISTANCE,
    SCORE_MAX,
)

logger = logging.getLogger("certtrace.scorer")

# Pre-compile regex patterns once at import time
_FIN_RE   = re.compile(FINANCIAL_KEYWORD_PATTERN, re.IGNORECASE)
_GLYPH_RE = re.compile(HOMOGLYPH_PATTERN,         re.IGNORECASE)


@dataclass
class ScoreResult:
    score:         int       = 0
    hits:          list[str] = field(default_factory=list)
    matched_brand: str | None = None


def _brand_hit(suspicious_name: str, brand_name: str) -> bool:
    """
    Return True if the suspicious domain name impersonates the brand.
    Three detection strategies (any one is sufficient):
      1. Direct Levenshtein distance ≤ LEVENSHTEIN_MAX_DISTANCE (2)
      2. Brand name is a substring of the suspicious name
         AND the suspicious name is NOT exactly the brand name
      3. Brand name substring + at least one separator (-, _, .) follows
         (catches: hdfcbank-secure, sbi.kyc, icici_login …)
    """
    s = suspicious_name.lower()
    b = brand_name.lower()

    # Exact match is not impersonation
    if s == b:
        return False

    # Strategy 1: raw Levenshtein
    if Levenshtein.distance(s, b) <= LEVENSHTEIN_MAX_DISTANCE:
        return True

    # Strategy 2: brand contained inside suspicious name
    if b in s:
        return True

    # Strategy 3: typo variants — drop/swap one char and check containment
    #   handles: hdfcbnk (missing 'a'), sbl (b→l swap for sbi)
    for i in range(len(b)):
        variant = b[:i] + b[i+1:]          # deletion
        if len(variant) >= 3 and variant in s:
            return True

    return False


def score_domain(
    full_domain:       str,
    subdomain:         str,
    registered_domain: str,
    tld:               str,
    issuer:            str,
    protected_targets: list[str],
) -> ScoreResult:
    """
    Run the 5-signal scoring rubric.
    Every signal is boolean — fires at most once per domain.
    Final score is hard-capped at SCORE_MAX (100).
    """
    result     = ScoreResult()
    domain_str = full_domain.lower()
    reg_lower  = registered_domain.lower()
    issuer_low = (issuer or "").lower()

    # Suspicious registered name (everything left of the TLD)
    suspicious_name = reg_lower.split(".")[0]   # e.g. "hdfcbank-secure-login"

    # ── Signal 1: Brand Impersonation (+40) ───────────────────────────────────
    for target_domain in protected_targets:
        brand_name = target_domain.split(".")[0].lower()   # "hdfcbank"

        # Skip exact legitimate domain
        if suspicious_name == brand_name:
            continue

        if _brand_hit(suspicious_name, brand_name):
            result.score        += WEIGHT_BRAND_IMPERSONATION
            result.matched_brand = brand_name
            result.hits.append(f"Brand Impersonation ({brand_name})")
            break   # score once for best match

    # ── Signal 2: Financial Keywords (+20) ────────────────────────────────────
    fin_matches = _FIN_RE.findall(domain_str)
    if fin_matches:
        result.score += WEIGHT_FINANCIAL_KEYWORDS
        unique_kws = list(dict.fromkeys(kw.lower() for kw in fin_matches))[:4]
        result.hits.append(f"Financial Keywords ({', '.join(unique_kws)})")

    # ── Signal 3: Digit / Homoglyph Substitution (+15) ────────────────────────
    if _GLYPH_RE.search(domain_str):
        result.score += WEIGHT_DIGIT_SUBSTITUTION
        result.hits.append("Digit Substitution / Homoglyph")

    # ── Signal 4: High-Risk TLD (+15) ─────────────────────────────────────────
    if tld.lower() in HIGH_RISK_TLDS:
        result.score += WEIGHT_HIGH_RISK_TLD
        result.hits.append(f"High-Risk TLD (.{tld})")

    # ── Signal 5: Free Certificate Authority (+10) ────────────────────────────
    if any(p in issuer_low for p in FREE_CA_PATTERNS):
        result.score += WEIGHT_FREE_CA
        result.hits.append("Free CA (Let's Encrypt / ZeroSSL)")

    # ── Hard cap ──────────────────────────────────────────────────────────────
    result.score = min(result.score, SCORE_MAX)

    if result.hits:
        logger.debug(f"[SCORE] {full_domain} → {result.score}/100  hits={result.hits}")

    return result
