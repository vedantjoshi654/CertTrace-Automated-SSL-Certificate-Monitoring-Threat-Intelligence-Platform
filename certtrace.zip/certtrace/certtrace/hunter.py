"""
CertTrace V3.0 — Active OSINT Hunter
Queries crt.sh for certificate records that contain monitored brand strings
and pushes discovered domains into the same worker queue used by CertStream.
"""

import asyncio
import logging
from collections.abc import Iterable

import aiohttp
import tldextract

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import (
    HUNTER_SWEEP_DELAY,
    HUNTER_BRAND_DELAY,
    HUNTER_REQUEST_TIMEOUT,
)

logger = logging.getLogger("certtrace.hunter")


def derive_target_brands(protected_targets: Iterable[str]) -> list[str]:
    """Extract search tokens from protected target domains."""
    brands: list[str] = []
    for target in protected_targets:
        if not target:
            continue
        candidate = target.strip().lower()
        if not candidate:
            continue

        ext = tldextract.extract(candidate)
        brand = ext.domain or candidate.split(".")[0]
        brand = brand.strip().lower()
        if brand and brand not in brands:
            brands.append(brand)

    return brands


async def active_osint_hunter(
    queue: asyncio.Queue,
    protected_targets: Iterable[str],
    sweep_delay: int = HUNTER_SWEEP_DELAY,
    brand_delay: int = HUNTER_BRAND_DELAY,
    request_timeout: int = HUNTER_REQUEST_TIMEOUT,
) -> None:
    """
    Search crt.sh for historical certificate entries containing target brands.

    Each discovered hostname is pushed into the main pipeline as a dict with
    the same shape as CertStream payloads: {"domain": ..., "issuer": ...}.
    """
    brands = derive_target_brands(protected_targets)
    if not brands:
        logger.info("[HUNTER] No target brands configured; hunter exiting.")
        return

    timeout = aiohttp.ClientTimeout(total=request_timeout)
    headers = {"User-Agent": "CertTrace/3.0 (+crt.sh hunter)"}
    seen: set[str] = set()
    search_counts: dict[str, int] = {}

    logger.info(
        "[HUNTER] Active OSINT hunter initialized for %d brand(s).",
        len(brands),
    )

    async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
        while True:
            for brand in brands:
                search_counts[brand] = search_counts.get(brand, 0) + 1
                found_count = 0
                url = f"https://crt.sh/?q=%25{brand}%25&output=json"
                try:
                    async with session.get(url) as response:
                        if response.status != 200:
                            logger.warning(
                                "[HUNTER] crt.sh returned HTTP %s for %s",
                                response.status,
                                brand,
                            )
                            continue

                        try:
                            records = await response.json(content_type=None)
                        except Exception:
                            logger.debug(
                                "[HUNTER] Non-JSON response received for %s",
                                brand,
                            )
                            continue

                        if not isinstance(records, list):
                            logger.debug(
                                "[HUNTER] Unexpected crt.sh payload type for %s: %s",
                                brand,
                                type(records).__name__,
                            )
                            continue

                        for entry in records:
                            if not isinstance(entry, dict):
                                continue

                            issuer = entry.get("issuer_name") or "Historical CA (crt.sh)"
                            raw_names = str(entry.get("name_value", "")).lower().splitlines()

                            for raw_name in raw_names:
                                clean_domain = raw_name.lstrip("*.").strip()
                                if not clean_domain or clean_domain in seen:
                                    continue
                                seen.add(clean_domain)

                                try:
                                    queue.put_nowait({"domain": clean_domain, "issuer": issuer})
                                    found_count += 1
                                except asyncio.QueueFull:
                                    logger.debug("[HUNTER] Queue full; dropping %s", clean_domain)

                        logger.info(
                            "[HUNTER] Found %d historical record(s) for '%s' (query #%d)",
                            found_count,
                            brand,
                            search_counts[brand],
                        )
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    logger.warning("[HUNTER] Search failed for %s: %s", brand, str(exc) or type(exc).__name__)

                await asyncio.sleep(brand_delay)

            logger.info("[HUNTER] Completed brand sweep. Sleeping for %ss.", sweep_delay)
            await asyncio.sleep(sweep_delay)