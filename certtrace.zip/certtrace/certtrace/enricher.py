"""
CertTrace V3.0 — Active Network Enrichment Engine
Performs DNS resolution, MX detection, and TLS fingerprinting
for any domain that breaches the 80-point score threshold.
"""

import asyncio
import logging
import socket
import ssl
from dataclasses import dataclass, field

import dns.resolver
import dns.exception

logger = logging.getLogger("certtrace.enricher")

# ── Result Model ─────────────────────────────────────────────────────────────

@dataclass
class EnrichmentResult:
    resolved_ips:       list[str] = field(default_factory=list)
    mail_servers:       list[str] = field(default_factory=list)
    tls_profile:        str       = "unknown"
    fingerprint_method: str       = "none"
    mail_configured:    bool      = False


# ── DNS Resolution ────────────────────────────────────────────────────────────

async def _resolve_ips(domain: str) -> list[str]:
    """Query A + AAAA records; return resolved IP strings."""
    ips: list[str] = []
    loop = asyncio.get_event_loop()

    def _query():
        result = []
        resolver = dns.resolver.Resolver()
        resolver.timeout = 3
        resolver.lifetime = 5
        for qtype in ("A", "AAAA"):
            try:
                ans = resolver.resolve(domain, qtype)
                for rdata in ans:
                    result.append(str(rdata))
            except (dns.exception.DNSException, Exception):
                pass
        return result

    try:
        ips = await asyncio.wait_for(
            loop.run_in_executor(None, _query), timeout=8
        )
    except asyncio.TimeoutError:
        logger.debug(f"[DNS] A/AAAA timeout for {domain}")
    except Exception as exc:
        logger.debug(f"[DNS] Error for {domain}: {exc}")

    return ips


async def _resolve_mx(domain: str) -> list[str]:
    """Query MX records; return list of mail exchanger hostnames."""
    mx_hosts: list[str] = []
    loop = asyncio.get_event_loop()

    def _query():
        resolver = dns.resolver.Resolver()
        resolver.timeout = 3
        resolver.lifetime = 5
        try:
            ans = resolver.resolve(domain, "MX")
            return [str(r.exchange).rstrip(".") for r in ans]
        except Exception:
            return []

    try:
        mx_hosts = await asyncio.wait_for(
            loop.run_in_executor(None, _query), timeout=8
        )
    except asyncio.TimeoutError:
        logger.debug(f"[MX] Timeout for {domain}")
    except Exception as exc:
        logger.debug(f"[MX] Error for {domain}: {exc}")

    return mx_hosts


# ── TLS Fingerprinting ────────────────────────────────────────────────────────

async def _fingerprint_ja4plus(domain: str) -> tuple[str, str]:
    """
    Attempt JA4+ fingerprinting via the ja4plus CLI tool.
    Returns (tls_profile, method_name) or raises on failure.
    """
    proc = await asyncio.create_subprocess_exec(
        "ja4plus", "--domain", domain, "--json",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
        import json
        data = json.loads(stdout.decode())
        ja4s = data.get("ja4s") or data.get("JA4S") or data.get("fingerprint", "")
        if ja4s:
            return ja4s, "ja4plus"
        raise ValueError("No JA4S hash in output")
    except asyncio.TimeoutError:
        proc.kill()
        raise


async def _fingerprint_pure_python(domain: str) -> tuple[str, str]:
    """
    Fallback: perform a raw TLS ClientHello via stdlib ssl + socket.
    Logs cipher suite + TLS version. Non-invasive (no HTTP request sent).
    """
    loop = asyncio.get_event_loop()

    def _handshake():
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        with socket.create_connection((domain, 443), timeout=6) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cipher = ssock.cipher()          # (name, protocol, bits)
                ver    = ssock.version() or "?"
                return f"{cipher[0]} | {ver}" if cipher else ver

    try:
        profile = await asyncio.wait_for(
            loop.run_in_executor(None, _handshake), timeout=10
        )
        return profile, "pure-python-ssl"
    except Exception as exc:
        return f"TLS_HANDSHAKE_FAILED ({type(exc).__name__})", "pure-python-ssl"


# ── Public Entry-Point ────────────────────────────────────────────────────────

async def enrich(domain: str) -> EnrichmentResult:
    """
    Full enrichment pipeline for a high-score domain:
      1. DNS A/AAAA resolution
      2. MX record check
      3. TLS fingerprinting (JA4+ → pure-Python fallback)
    """
    result = EnrichmentResult()

    # Run DNS and MX concurrently
    ips, mx = await asyncio.gather(
        _resolve_ips(domain),
        _resolve_mx(domain),
    )
    result.resolved_ips = ips
    result.mail_servers = mx
    result.mail_configured = len(mx) > 0

    if result.mail_configured:
        logger.warning(
            f"[MX ⚠️] {domain} has active mail infrastructure: {mx}"
        )

    # TLS fingerprint — try JA4+ first, silently fall back
    try:
        profile, method = await _fingerprint_ja4plus(domain)
    except Exception:
        logger.debug(f"[TLS] JA4+ unavailable for {domain} — falling back to pure-Python")
        profile, method = await _fingerprint_pure_python(domain)

    result.tls_profile        = profile
    result.fingerprint_method = method

    logger.info(
        f"[ENRICHED] {domain} | IPs={ips} | MX={mx} | "
        f"TLS={profile} ({method})"
    )
    return result
