"""
CertTrace V3.0 — Consumer Worker Pool
asyncio.TaskGroup-managed pool of domain-processing workers.
Each worker implements strict error isolation so the pool never dies.
"""

import asyncio
import logging
import tldextract
from typing import Callable

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import (
    WORKER_COUNT,
    SCORE_CRITICAL,
)
from certtrace.scorer   import score_domain
from certtrace.enricher import enrich
from certtrace.database import insert_ioc
from certtrace.allowlist import is_allowlisted

logger = logging.getLogger("certtrace.worker")

# Protected targets are loaded at startup by main.py and stored here
_protected_targets: list[str] = []
_protected_set:     set[str]  = set()

# Broadcast callback — set by api.py to push live events over WebSocket
_broadcast_cb: Callable | None = None


def configure(
    protected_targets: list[str],
    broadcast_cb: Callable | None = None,
) -> None:
    global _protected_targets, _protected_set, _broadcast_cb
    _protected_targets = protected_targets
    _protected_set     = set(protected_targets)
    _broadcast_cb      = broadcast_cb


# ── Single Worker ─────────────────────────────────────────────────────────────

async def _worker(queue: asyncio.Queue, worker_id: int) -> None:
    """
    Consume items from the queue forever.
    Strict try/except ensures one bad payload never kills the worker.
    """
    logger.debug(f"[W{worker_id}] Worker started")

    while True:
        item = await queue.get()
        try:
            await _process(item)
        except Exception as exc:
            logger.error(
                f"[W{worker_id}] Unhandled exception on payload {item!r}: {exc}",
                exc_info=True,
            )
        finally:
            queue.task_done()


# ── 4-Step Pipeline ───────────────────────────────────────────────────────────

async def _process(item: dict) -> None:
    raw_domain = item.get("domain", "")
    issuer     = item.get("issuer", "Unknown CA")

    # ── Step 1: Domain Parsing & Normalisation ────────────────────────────────
    # Strip wildcard prefix
    clean_domain = raw_domain.lstrip("*.").strip().lower()
    if not clean_domain or "." not in clean_domain:
        return

    ext = tldextract.extract(clean_domain)
    if not ext.domain or not ext.suffix:
        return  # Unparseable — skip

    registered_domain = f"{ext.domain}.{ext.suffix}"
    full_domain       = f"{ext.subdomain}.{registered_domain}" if ext.subdomain else registered_domain

    # ── Step 2: Protected Brand Check ─────────────────────────────────────────
    if registered_domain in _protected_set:
        logger.debug(f"[FILTER] Protected brand: {registered_domain}")
        return

    # ── Step 3: Tranco Allowlist Filtering ───────────────────────────────────
    if is_allowlisted(registered_domain):
        logger.debug(f"[FILTER] Allowlisted: {registered_domain}")
        return

    # ── Step 4: Heuristic Scoring ─────────────────────────────────────────────
    result = score_domain(
        full_domain       = full_domain,
        subdomain         = ext.subdomain,
        registered_domain = registered_domain,
        tld               = ext.suffix,
        issuer            = issuer,
        protected_targets = _protected_targets,
    )

    if result.score < SCORE_CRITICAL:
        logger.debug(f"[BELOW_THRESHOLD] {full_domain} score={result.score}")
        return

    logger.info(
        f"[THREAT] {full_domain} score={result.score}/100 "
        f"hits={result.hits}"
    )

    # ── Active Enrichment ─────────────────────────────────────────────────────
    enrichment = await enrich(full_domain)

    # ── Persist to Database ───────────────────────────────────────────────────
    ioc_id = await insert_ioc(
        phishing_domain     = full_domain,
        certificate_issuer  = issuer,
        threat_score        = result.score,
        resolved_ips        = enrichment.resolved_ips,
        mail_servers        = enrichment.mail_servers,
        tls_profile         = enrichment.tls_profile,
        fingerprint_method  = enrichment.fingerprint_method,
        heuristic_hits      = result.hits,
    )

    # ── Broadcast to Live Dashboard ───────────────────────────────────────────
    if _broadcast_cb is not None:
        event_payload = {
            "ioc_id":             ioc_id,
            "timestamp":          None,         # DB default fills this
            "phishing_domain":    full_domain,
            "certificate_issuer": issuer,
            "threat_score":       result.score,
            "heuristic_hits":     result.hits,
            "resolved_ips":       enrichment.resolved_ips,
            "mail_servers":       enrichment.mail_servers,
            "mail_configured":    enrichment.mail_configured,
            "tls_profile":        enrichment.tls_profile,
            "fingerprint_method": enrichment.fingerprint_method,
        }
        try:
            await _broadcast_cb(event_payload)
        except Exception as exc:
            logger.debug(f"[WS_BROADCAST] Error: {exc}")


# ── Worker Pool ───────────────────────────────────────────────────────────────

async def run_worker_pool(queue: asyncio.Queue) -> None:
    """
    Launch WORKER_COUNT consumers inside an asyncio.TaskGroup.
    The TaskGroup keeps all workers alive; individual worker exceptions
    are already caught inside _worker, so the group never raises.
    """
    logger.info(f"[POOL] Starting {WORKER_COUNT} consumer workers …")
    async with asyncio.TaskGroup() as tg:
        for i in range(WORKER_COUNT):
            tg.create_task(_worker(queue, i))
