"""
CertTrace V3.0 — Allowlist Manager
Loads and manages the Tranco Top 1M trusted domain list.
Provides O(1) lookup via an in-memory set.
"""

import csv
import io
import logging
import zipfile
from pathlib import Path

import requests

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import TRANCO_PATH, TRANCO_URL

logger = logging.getLogger("certtrace.allowlist")

_allowlist: set[str] = set()


def load_allowlist() -> None:
    """Load the Tranco CSV into memory. Auto-downloads if missing."""
    global _allowlist
    if not TRANCO_PATH.exists():
        logger.warning("Tranco list not found — triggering auto-download.")
        refresh_allowlist()
    else:
        _read_csv(TRANCO_PATH)


def _read_csv(path: Path) -> None:
    global _allowlist
    _allowlist = set()
    try:
        with open(path, newline="", encoding="utf-8", errors="ignore") as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) >= 2:
                    _allowlist.add(row[1].strip().lower())
                elif len(row) == 1:
                    _allowlist.add(row[0].strip().lower())
        logger.info(f"Allowlist loaded: {len(_allowlist):,} trusted domains")
    except Exception as exc:
        logger.error(f"Failed to read Tranco CSV: {exc}")


def refresh_allowlist() -> None:
    """Download a fresh Tranco Top 1M list and save it locally."""
    logger.info(f"Downloading Tranco list from {TRANCO_URL} …")
    try:
        resp = requests.get(TRANCO_URL, timeout=120, stream=True)
        resp.raise_for_status()
        raw = io.BytesIO(resp.content)
        with zipfile.ZipFile(raw) as zf:
            csv_name = next(n for n in zf.namelist() if n.endswith(".csv"))
            with zf.open(csv_name) as src, open(TRANCO_PATH, "wb") as dst:
                dst.write(src.read())
        logger.info(f"Tranco list saved to {TRANCO_PATH}")
        _read_csv(TRANCO_PATH)
    except Exception as exc:
        logger.error(f"Allowlist refresh failed: {exc}")
        # Seed a minimal fallback so the pipeline can still operate
        _seed_minimal_fallback()


def _seed_minimal_fallback() -> None:
    """Seed the in-memory set with ~200 well-known safe domains when offline."""
    global _allowlist
    fallback = {
        "google.com", "youtube.com", "facebook.com", "twitter.com",
        "instagram.com", "linkedin.com", "microsoft.com", "apple.com",
        "amazon.com", "netflix.com", "wikipedia.org", "reddit.com",
        "github.com", "stackoverflow.com", "cloudflare.com", "akamai.com",
        "amazonaws.com", "azure.com", "office.com", "live.com",
        "yahoo.com", "bing.com", "duckduckgo.com", "mozilla.org",
        "adobe.com", "salesforce.com", "dropbox.com", "slack.com",
        "zoom.us", "stripe.com", "shopify.com", "twilio.com",
        "fastly.com", "cdn77.com", "gstatic.com", "googleapis.com",
    }
    _allowlist.update(fallback)
    logger.warning(f"Using minimal fallback allowlist ({len(fallback)} domains).")


def is_allowlisted(registered_domain: str) -> bool:
    """Return True if the domain is on the Tranco Top 1M list."""
    return registered_domain.lower() in _allowlist


def allowlist_size() -> int:
    return len(_allowlist)
