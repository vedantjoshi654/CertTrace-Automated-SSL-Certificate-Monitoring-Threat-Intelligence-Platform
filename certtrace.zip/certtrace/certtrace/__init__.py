"""CertTrace V3.0 — Package Init"""
__version__ = "3.0.0"
__author__  = "CertTrace Intelligence Engine"
