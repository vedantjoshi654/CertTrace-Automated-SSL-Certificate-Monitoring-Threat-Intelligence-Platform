"""
CertTrace V3.0 — Shodan OSINT Integration
Enriches an IP address with Shodan host intelligence:
  - Open ports and running services
  - CVEs / vulnerabilities
  - ASN, ISP, organisation, country
  - Bulletproof hosting indicators
  - Historical hostnames

Gracefully degrades when no API key is configured.
"""

import asyncio
import logging
import os

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import SHODAN_API_KEY

logger = logging.getLogger("certtrace.shodan")

# ── Known bulletproof / bad-reputation ASNs ───────────────────────────────────
BULLETPROOF_ASNS = {
    200052, 60781, 3214, 49453, 206485, 202425, 59711, 8100,
    394711, 34549, 51167, 60068, 44050, 209588,
}

BULLETPROOF_ORGS = {
    "frantech solutions", "sharktech", "m247 ltd", "combahton",
    "hostkey", "vdsina", "selectel", "alexhost", "vpsvim",
    "itldc", "novogara", "serverius", "quasi networks",
    "lir llc", "serverius-as", "relink ltd",
}


async def lookup_shodan(ip: str) -> dict:
    """
    Query Shodan for a given IP address.
    Returns structured intelligence or a graceful error dict.
    """
    if not SHODAN_API_KEY or SHODAN_API_KEY == "YOUR_SHODAN_API_KEY":
        logger.info(f"[SHODAN] No API key — skipping for {ip}")
        return _no_key_result(ip)

    loop = asyncio.get_event_loop()

    def _query():
        import shodan
        api  = shodan.Shodan(SHODAN_API_KEY)
        return api.host(ip)

    try:
        data = await asyncio.wait_for(
            loop.run_in_executor(None, _query),
            timeout=15
        )
    except asyncio.TimeoutError:
        return _error_result(ip, "Shodan API timeout")
    except Exception as e:
        err = str(e)
        if "No information available" in err:
            return _error_result(ip, "No Shodan data for this IP")
        return _error_result(ip, err)

    # Extract ports and services
    ports    = sorted(set(s.get("port", 0) for s in data.get("data", [])))
    services = []
    for s in data.get("data", [])[:8]:
        svc = {
            "port":     s.get("port"),
            "protocol": s.get("transport", "tcp").upper(),
            "product":  s.get("product") or s.get("http", {}).get("title") or "Unknown",
            "version":  s.get("version", ""),
            "banner":   (s.get("data") or "")[:120].strip(),
        }
        services.append(svc)

    # CVEs
    vulns = list(data.get("vulns", {}).keys())[:10]

    # ASN / org
    asn   = data.get("asn", "")
    org   = data.get("org", "Unknown")
    isp   = data.get("isp", "Unknown")
    country = data.get("country_name", "Unknown")
    city    = data.get("city", "")

    # Hostnames
    hostnames = data.get("hostnames", [])[:6]

    # Tags (shodan threat tags)
    tags = data.get("tags", [])

    # Bulletproof detection
    asn_num = int(asn.replace("AS", "").strip()) if asn else 0
    is_bulletproof = (
        asn_num in BULLETPROOF_ASNS or
        any(b in org.lower() for b in BULLETPROOF_ORGS)
    )

    risk_flags = []
    if is_bulletproof:
        risk_flags.append(f"Bulletproof Hosting (ASN {asn} / {org})")
    if vulns:
        risk_flags.append(f"{len(vulns)} CVE(s) exposed: {', '.join(vulns[:3])}")
    if "tor" in tags:
        risk_flags.append("Tor Exit Node")
    if "vpn" in tags:
        risk_flags.append("VPN / Proxy Infrastructure")
    if any(p in ports for p in [4443, 8443, 2083, 2087]):
        risk_flags.append("Non-standard HTTPS ports detected (phishing panel indicator)")

    result = {
        "ip":             ip,
        "asn":            asn,
        "org":            org,
        "isp":            isp,
        "country":        country,
        "city":           city,
        "hostnames":      hostnames,
        "open_ports":     ports,
        "services":       services,
        "vulns":          vulns,
        "tags":           tags,
        "last_update":    data.get("last_update", "Unknown"),
        "is_bulletproof": is_bulletproof,
        "risk_flags":     risk_flags,
        "error":          None,
        "source":         "shodan",
    }

    logger.info(
        f"[SHODAN] {ip} | ASN={asn} | org={org} | "
        f"ports={ports[:5]} | vulns={len(vulns)} | bp={is_bulletproof}"
    )
    return result


async def lookup_ip_whois(ip: str) -> dict:
    """
    Fallback ASN/org lookup using ipwhois (no API key required).
    Used when Shodan is unavailable.
    """
    loop = asyncio.get_event_loop()

    def _query():
        from ipwhois import IPWhois
        obj    = IPWhois(ip)
        result = obj.lookup_rdap(depth=1)
        return result

    try:
        data = await asyncio.wait_for(
            loop.run_in_executor(None, _query),
            timeout=10
        )
        asn      = data.get("asn", "Unknown")
        asn_desc = data.get("asn_description", "Unknown")
        asn_country = data.get("asn_country_code", "Unknown")
        cidr     = data.get("asn_cidr", "Unknown")

        asn_num = int(str(asn).strip()) if str(asn).strip().isdigit() else 0
        is_bulletproof = asn_num in BULLETPROOF_ASNS or \
                         any(b in (asn_desc or "").lower() for b in BULLETPROOF_ORGS)

        risk_flags = []
        if is_bulletproof:
            risk_flags.append(f"Bulletproof Hosting (ASN {asn} / {asn_desc})")

        return {
            "ip":             ip,
            "asn":            f"AS{asn}",
            "org":            asn_desc,
            "isp":            asn_desc,
            "country":        asn_country,
            "city":           "",
            "hostnames":      [],
            "open_ports":     [],
            "services":       [],
            "vulns":          [],
            "tags":           [],
            "last_update":    "Unknown",
            "is_bulletproof": is_bulletproof,
            "risk_flags":     risk_flags,
            "error":          None,
            "source":         "ipwhois",
            "cidr":           cidr,
        }
    except Exception as e:
        return _error_result(ip, f"ipwhois failed: {e}")


def _no_key_result(ip: str) -> dict:
    return {**_error_result(ip, "Shodan API key not configured"),
            "source": "none", "risk_flags": []}


def _error_result(ip: str, error: str) -> dict:
    return {
        "ip": ip, "asn": "Unknown", "org": "Unknown", "isp": "Unknown",
        "country": "Unknown", "city": "", "hostnames": [], "open_ports": [],
        "services": [], "vulns": [], "tags": [], "last_update": "Unknown",
        "is_bulletproof": False, "risk_flags": [], "error": error,
        "source": "error", "cidr": "",
    }
