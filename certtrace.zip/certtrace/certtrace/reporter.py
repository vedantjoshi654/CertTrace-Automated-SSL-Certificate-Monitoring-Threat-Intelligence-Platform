"""
CertTrace V3.0 — IOC Report Formatter
Renders a database row into the spec's plaintext intelligence brief
and a structured dict for API/dashboard consumption.
"""



def _defang(domain: str) -> str:
    """Replace last dot before TLD with [.] for safe sharing."""
    parts = domain.rsplit(".", 1)
    if len(parts) == 2:
        return f"{parts[0]}[.]{parts[1]}"
    return domain


def format_plaintext(row: dict) -> str:
    """Render a full IOC Analysis Report in spec-compliant plaintext."""
    ts        = row.get("timestamp", "—")
    domain    = row.get("phishing_domain", "—")
    issuer    = row.get("certificate_issuer", "—")
    score     = row.get("threat_score", 0)
    ips       = row.get("resolved_ips", "") or ""
    mx        = row.get("mail_servers", "") or ""
    tls       = row.get("tls_profile", "—")
    method    = row.get("fingerprint_method", "—")
    verdict   = row.get("analyst_verdict", "pending")
    hits      = row.get("heuristic_hits", "") or ""
    notes     = row.get("notes", "") or ""

    # Status label
    if score >= 90:
        status_label = "🚨 CRITICAL MATCH"
    elif score >= 80:
        status_label = "⚠️  HIGH THREAT"
    elif score >= 60:
        status_label = "🟡 MEDIUM RISK"
    else:
        status_label = "ℹ️  LOW RISK"

    ip_list = [ip.strip() for ip in ips.split(",") if ip.strip()]
    mx_list = [m.strip() for m in mx.split(",") if m.strip()]

    # IP lines
    ip_lines = "\n".join(
        f"     {ip}" for ip in ip_list
    ) if ip_list else "     None resolved"

    # MX lines + mail infrastructure alert
    if mx_list:
        mx_lines = "\n".join(f"     {m}" for m in mx_list)
        mx_lines += (
            "\n     ⚠️  CRITICAL: Active Mail Infrastructure Configured."
            "\n     High probability of active email phishing vector."
        )
    else:
        mx_lines = "     None detected"

    # Method label
    method_label = "ja4plus (Native Packet Capture Engine)" if method == "ja4plus" \
        else "pure-python-ssl (Stdlib Fallback)"

    report = f"""
{'='*80}
{'                    CERTTRACE IOC ANALYSIS REPORT':^80}
{'='*80}
Detection Time : {ts} UTC
Target Status  : {status_label} (Threat Score: {score}/100)
{'-'*80}
Domain Profile
  ↳ Flagged Domain : {_defang(domain)}
  ↳ Cert Issuer    : {issuer}
  ↳ Heuristic Hits : {hits if hits else 'None'}

Infrastructure Profile
  ↳ Resolved IPs   :
{ip_lines}
  ↳ MX Mail Servers:
{mx_lines}

Cryptographic Signature
  ↳ TLS Profile    : {tls}
  ↳ Profile Method : {method_label}
{'-'*80}
Investigator State
  ↳ Current State  : {verdict}
  ↳ Notes          : {notes if notes else '(none)'}
  ↳ Action Log     : [ Update Status to Confirmed / False Positive ]
{'='*80}
""".strip()

    return report


def format_structured(row: dict) -> dict:
    """Return a structured dict for API/dashboard use."""
    domain  = row.get("phishing_domain", "")
    score   = row.get("threat_score", 0)
    ips_raw = row.get("resolved_ips", "") or ""
    mx_raw  = row.get("mail_servers",  "") or ""
    hits    = row.get("heuristic_hits", "") or ""

    return {
        "ioc_id":             row.get("ioc_id"),
        "timestamp":          row.get("timestamp"),
        "phishing_domain":    domain,
        "defanged_domain":    _defang(domain),
        "certificate_issuer": row.get("certificate_issuer"),
        "threat_score":       score,
        "severity":           _severity(score),
        "resolved_ips":       [ip.strip() for ip in ips_raw.split(",") if ip.strip()],
        "mail_servers":       [m.strip() for m in mx_raw.split(",")  if m.strip()],
        "mail_configured":    bool(mx_raw.strip()),
        "tls_profile":        row.get("tls_profile"),
        "fingerprint_method": row.get("fingerprint_method"),
        "analyst_verdict":    row.get("analyst_verdict", "pending"),
        "notes":              row.get("notes"),
        "heuristic_hits":     [h.strip() for h in hits.split(",") if h.strip()],
        "plaintext_report":   format_plaintext(row),
    }


def _severity(score: int) -> str:
    if score >= 90:
        return "critical"
    if score >= 80:
        return "high"
    if score >= 60:
        return "medium"
    return "low"
