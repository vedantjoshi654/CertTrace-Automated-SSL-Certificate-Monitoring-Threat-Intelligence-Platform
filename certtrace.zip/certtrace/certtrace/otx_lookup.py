import aiohttp
import logging

logger = logging.getLogger("certtrace.otx")

async def lookup_otx(target: str, is_ip: bool) -> dict:
    """Fetch intelligence from AlienVault OTX."""
    indicator_type = "IPv4" if is_ip else "domain"
    url = f"https://otx.alienvault.com/api/v1/indicators/{indicator_type}/{target}/general"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10, ssl=False) as response:
                if response.status == 200:
                    data = await response.json()
                    pulses = data.get("pulse_info", {}).get("count", 0)
                    tags = []
                    for p in data.get("pulse_info", {}).get("pulses", []):
                        tags.extend(p.get("tags", []))
                    tags = list(set(tags))[:5]
                    return {
                        "pulses": pulses,
                        "tags": tags,
                        "error": None
                    }
                else:
                    return {"error": f"OTX returned HTTP {response.status}"}
    except Exception as e:
        logger.error(f"[OTX] Error looking up {target}: {e}")
        return {"error": str(e)}
