"""
CertTrace V3.0 — Manual Investigation Orchestrator
Accepts a user-submitted domain / URL / IP, runs the full analysis pipeline,
and returns a complete enriched intelligence report.
"""

import asyncio
import ipaddress
import logging
from datetime import datetime, timezone
from urllib.parse import urlparse

import tldextract

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from certtrace.scorer      import score_domain
from certtrace.enricher    import enrich
from certtrace.whois_lookup import lookup_whois, _compute_risk_flags
from certtrace.shodan_lookup import lookup_shodan, lookup_ip_whois
from certtrace.otx_lookup import lookup_otx
from certtrace.database    import insert_ioc
from certtrace.reporter    import _severity
import aiohttp

logger = logging.getLogger("certtrace.investigator")

_protected_targets: list[str] = []


def configure(protected_targets: list[str]) -> None:
    global _protected_targets
    _protected_targets = protected_targets


def _is_ip(s: str) -> bool:
    try:
        ipaddress.ip_address(s)
        return True
    except ValueError:
        return False


def _normalize_input(raw: str) -> tuple[str, str, str]:
    """
    Parse raw user input (domain / URL / IP) into:
      (target_type, clean_target, domain_or_ip)

    Returns:
      target_type: "domain" | "ip" | "url"
      clean_target: normalized string for display
      domain_or_ip: the host to investigate
    """
    raw = raw.strip().lower()

    # URL with scheme
    if raw.startswith(("http://", "https://", "ftp://")):
        parsed = urlparse(raw)
        host   = parsed.hostname or raw
        return "url", raw, host

    # Bare IP
    if _is_ip(raw):
        return "ip", raw, raw

    # Domain with or without path — strip path
    domain = raw.split("/")[0].split("?")[0].split("#")[0]
    # Strip www.
    if domain.startswith("www."):
        domain = domain[4:]
    return "domain", domain, domain


async def investigate(
    raw_input: str,
    save_to_db: bool = True,
    broadcast_cb=None,
) -> dict:
    """
    Full manual investigation pipeline:
      1. Normalise input
      2. Score domain (if applicable)
      3. DNS / MX / TLS enrichment
      4. WHOIS lookup
      5. Shodan / ipwhois lookup (for each resolved IP)
      6. Persist to DB
      7. Return structured result
    """
    ts = datetime.now(timezone.utc).isoformat()
    target_type, clean_target, host = _normalize_input(raw_input)

    logger.info(f"[INVESTIGATE] {raw_input!r} → type={target_type} host={host}")

    result = {
        "timestamp":      ts,
        "raw_input":      raw_input,
        "clean_target":   clean_target,
        "target_type":    target_type,
        "host":           host,
        "scoring":        None,
        "enrichment":     None,
        "whois":          None,
        "shodan":         [],
        "otx":            None,
        "hackertarget":   None,
        "urlhaus":        None,
        "ioc_id":         None,
        "plaintext_report": "",
    }

    # ── Step 1: Heuristic Scoring (domain targets only) ────────────────────────
    if target_type in ("domain", "url") and not _is_ip(host):
        ext = tldextract.extract(host)
        if ext.domain and ext.suffix:
            score_res = score_domain(
                full_domain       = host,
                subdomain         = ext.subdomain,
                registered_domain = f"{ext.domain}.{ext.suffix}",
                tld               = ext.suffix,
                issuer            = "Manual Investigation",
                protected_targets = _protected_targets,
            )
            result["scoring"] = {
                "score":         score_res.score,
                "severity":      _severity(score_res.score),
                "hits":          score_res.hits,
                "matched_brand": score_res.matched_brand,
            }
        else:
            result["scoring"] = {"score": 0, "severity": "low", "hits": [], "matched_brand": None}
    else:
        result["scoring"] = {"score": 0, "severity": "info", "hits": ["Manual IP investigation"], "matched_brand": None}

    # ── Step 2: DNS / MX / TLS Enrichment ─────────────────────────────────────
    enrichment = await enrich(host)
    result["enrichment"] = {
        "resolved_ips":    enrichment.resolved_ips,
        "mail_servers":    enrichment.mail_servers,
        "mail_configured": enrichment.mail_configured,
        "tls_profile":     enrichment.tls_profile,
        "fingerprint_method": enrichment.fingerprint_method,
    }

    # ── Step 3: WHOIS Lookup ───────────────────────────────────────────────────
    whois_target = host if not _is_ip(host) else host
    result["whois"] = await _manual_whoisxml_lookup(whois_target)

    # ── Step 4: Shodan / ipwhois for each resolved IP ─────────────────────────
    ips_to_scan = enrichment.resolved_ips or ([host] if _is_ip(host) else [])
    shodan_tasks = [_get_ip_intel(ip) for ip in ips_to_scan[:4]]
    result["shodan"] = await asyncio.gather(*shodan_tasks)

    # ── Step 4.5: AlienVault OTX, HackerTarget & URLhaus ────────────────────────
    otx_task = lookup_otx(host, _is_ip(host))
    ht_task = _lookup_hackertarget(host, _is_ip(host))
    urlhaus_task = _lookup_urlhaus(host)
    result["otx"], result["hackertarget"], result["urlhaus"] = await asyncio.gather(otx_task, ht_task, urlhaus_task)

    # ── Step 5: Persist to DB (if score passes threshold or manual override) ───
    score = result["scoring"]["score"]
    hits  = result["scoring"]["hits"]

    if save_to_db:
        ioc_id = await insert_ioc(
            phishing_domain    = host,
            certificate_issuer = "Manual Investigation",
            threat_score       = score,
            resolved_ips       = enrichment.resolved_ips,
            mail_servers       = enrichment.mail_servers,
            tls_profile        = enrichment.tls_profile,
            fingerprint_method = enrichment.fingerprint_method,
            heuristic_hits     = hits,
        )
        result["ioc_id"] = ioc_id

    # ── Step 6: Build plaintext report ────────────────────────────────────────
    result["plaintext_report"] = _build_report(result)

    # ── Step 7: Broadcast to live dashboard ───────────────────────────────────
    if broadcast_cb and result["ioc_id"]:
        try:
            await broadcast_cb({
                "ioc_id":          result["ioc_id"],
                "phishing_domain": host,
                "threat_score":    score,
                "heuristic_hits":  hits,
                "resolved_ips":    enrichment.resolved_ips,
                "mail_servers":    enrichment.mail_servers,
                "mail_configured": enrichment.mail_configured,
                "tls_profile":     enrichment.tls_profile,
                "fingerprint_method": enrichment.fingerprint_method,
                "certificate_issuer": "Manual Investigation",
            })
        except Exception:
            pass

    return result


async def _get_ip_intel(ip: str) -> dict:
    """Try Shodan first, fall back to ipwhois."""
    shodan_res = await _manual_shodan_lookup(ip)
    if shodan_res.get("error") and shodan_res.get("source") != "error":
        shodan_res = await lookup_ip_whois(ip)
    elif shodan_res.get("source") == "none":
        # No API key — use ipwhois
        shodan_res = await lookup_ip_whois(ip)
    return shodan_res

async def _lookup_hackertarget(target: str, is_ip: bool) -> dict:
    if is_ip:
        url = f"https://api.hackertarget.com/reverseiplookup/?q={target}"
    else:
        url = f"https://api.hackertarget.com/hostsearch/?q={target}"
        
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10, ssl=False) as response:
                if response.status == 200:
                    text = await response.text()
                    if "error" in text.lower():
                        return {"result": None, "error": text.strip()}
                    return {"result": text.strip(), "error": None}
                return {"error": f"HTTP {response.status}"}
    except Exception as e:
        return {"error": str(e)}

async def _lookup_urlhaus(target: str) -> dict:
    url = "https://urlhaus-api.abuse.ch/v1/host/"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data={"host": target}, timeout=10, ssl=False) as response:
                if response.status == 200:
                    return await response.json()
                return {"error": f"HTTP {response.status}"}
    except Exception as e:
        return {"error": str(e)}

async def _manual_shodan_lookup(ip: str) -> dict:
    url = f"https://api.shodan.io/shodan/host/{ip}?key=UfsBX2sZx6oDorR0hY88kAsafdcRPIq2"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15, ssl=False) as response:
                if response.status == 200:
                    data = await response.json()
                    ports    = sorted(set(s.get("port", 0) for s in data.get("data", [])))
                    services = []
                    for s in data.get("data", [])[:8]:
                        svc = {
                            "port":     s.get("port"),
                            "protocol": s.get("transport", "tcp").upper() if s.get("transport") else "TCP",
                            "product":  s.get("product") or (s.get("http", {}) or {}).get("title") or "Unknown",
                            "version":  s.get("version", ""),
                            "banner":   str(s.get("data", ""))[:120].strip(),
                        }
                        services.append(svc)
                    
                    vulns = list(data.get("vulns", {}).keys())[:10] if data.get("vulns") else []
                    asn = data.get("asn", "")
                    org = data.get("org", "Unknown")
                    isp = data.get("isp", "Unknown")
                    country = data.get("country_name", "Unknown")
                    city = data.get("city", "")
                    hostnames = data.get("hostnames", [])[:6]
                    tags = data.get("tags", [])
                    
                    BULLETPROOF_ASNS = {200052, 60781, 3214, 49453, 206485, 202425, 59711, 8100, 394711, 34549, 51167, 60068, 44050, 209588}
                    BULLETPROOF_ORGS = {"frantech solutions", "sharktech", "m247 ltd", "combahton", "hostkey", "vdsina", "selectel", "alexhost", "vpsvim", "itldc", "novogara", "serverius", "quasi networks", "lir llc", "serverius-as", "relink ltd"}
                    asn_num = int(str(asn).replace("AS", "").strip()) if asn and str(asn).replace("AS", "").strip().isdigit() else 0
                    is_bulletproof = asn_num in BULLETPROOF_ASNS or any(b in org.lower() for b in BULLETPROOF_ORGS)
                    
                    risk_flags = []
                    if is_bulletproof: risk_flags.append(f"Bulletproof Hosting (ASN {asn} / {org})")
                    if vulns: risk_flags.append(f"{len(vulns)} CVE(s) exposed: {', '.join(vulns[:3])}")
                    if "tor" in tags: risk_flags.append("Tor Exit Node")
                    if "vpn" in tags: risk_flags.append("VPN / Proxy Infrastructure")
                    if any(p in ports for p in [4443, 8443, 2083, 2087]): risk_flags.append("Non-standard HTTPS ports detected")
                    
                    return {
                        "ip": ip, "asn": asn, "org": org, "isp": isp, "country": country, "city": city,
                        "hostnames": hostnames, "open_ports": ports, "services": services, "vulns": vulns,
                        "tags": tags, "last_update": data.get("last_update", "Unknown"),
                        "is_bulletproof": is_bulletproof, "risk_flags": risk_flags, "error": None, "source": "shodan"
                    }
                else:
                    return {"error": f"Shodan API HTTP {response.status}", "source": "none"}
    except Exception as e:
        return {"error": str(e), "source": "none"}

def _empty_whois(target, err):
    return {
        "target": target, "registrar": "Unknown", "registrant_org": "Unknown",
        "registrant_email": "Unknown", "registrant_country": "Unknown",
        "creation_date": "Unknown", "expiry_date": "Unknown", "updated_date": "Unknown",
        "domain_age_days": None, "newly_registered": False, "expiring_soon": False,
        "name_servers": [], "dnssec": "Unknown", "statuses": [], "error": err, "risk_flags": []
    }

async def _manual_whoisxml_lookup(target: str) -> dict:
    url = f"https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=at_tOK4S4zaJECTWjXz6E9h4RmMY7shC&domainName={target}&outputFormat=JSON"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15, ssl=False) as response:
                if response.status == 200:
                    data = await response.json()
                    w = data.get("WhoisRecord", {})
                    
                    def _dt(s): 
                        if not s: return None
                        try: return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                        except: return None
                        
                    creation = _dt(w.get("createdDateNormalized"))
                    expiry = _dt(w.get("expiresDateNormalized"))
                    updated = _dt(w.get("updatedDateNormalized"))
                    
                    now = datetime.now(timezone.utc)
                    domain_age_days = (now - creation).days if creation else None
                    newly_registered = (domain_age_days < 30) if domain_age_days is not None else False
                    
                    # Need timedelta for expiring soon
                    from datetime import timedelta
                    expiring_soon = (expiry - now) < timedelta(days=30) if expiry else False
                    
                    name_servers = []
                    if "nameServers" in w and "hostNames" in w["nameServers"]:
                        name_servers = w["nameServers"]["hostNames"][:6]
                        
                    status_val = w.get("status", "")
                    if isinstance(status_val, list):
                        status_val = " ".join(status_val)
                    statuses = [s.split(" ")[0] for s in status_val.split() if s][:4]
                    
                    registrar = w.get("registrarName", "Unknown")
                    org = w.get("registrant", {}).get("organization", "Unknown")
                    country = w.get("registrant", {}).get("country", "Unknown")
                    email = w.get("contactEmail", "Unknown")
                    
                    risk_flags = _compute_risk_flags(newly_registered, expiring_soon, name_servers, "Unknown", statuses)
                    
                    return {
                        "target": target, "registrar": registrar, "registrant_org": org,
                        "registrant_email": email, "registrant_country": country,
                        "creation_date": creation.isoformat() if creation else "Unknown",
                        "expiry_date": expiry.isoformat() if expiry else "Unknown",
                        "updated_date": updated.isoformat() if updated else "Unknown",
                        "domain_age_days": domain_age_days, "newly_registered": newly_registered,
                        "expiring_soon": expiring_soon, "name_servers": name_servers,
                        "dnssec": "Unknown", "statuses": statuses, "error": None, "risk_flags": risk_flags
                    }
                else:
                    return _empty_whois(target, f"WhoisXML API HTTP {response.status}")
    except Exception as e:
        return _empty_whois(target, str(e))


def _build_report(r: dict) -> str:
    """Render the full investigation report in plaintext."""
    ts        = r["timestamp"]
    host      = r["clean_target"]
    score     = r["scoring"]["score"]
    severity  = r["scoring"]["severity"].upper()
    hits      = r["scoring"]["hits"]
    enr       = r["enrichment"] or {}
    whois     = r["whois"] or {}
    shodans   = r["shodan"] or []

    ips       = enr.get("resolved_ips", [])
    mx        = enr.get("mail_servers", [])
    tls       = enr.get("tls_profile", "Unknown")
    method    = enr.get("fingerprint_method", "unknown")

    sev_icon = {"CRITICAL": "[!!!]", "HIGH": "[!!]", "MEDIUM": "[*]", "LOW": "[+]", "INFO": "[i]"}.get(severity, "[?]")

    lines = [
        "=" * 80,
        "          CERTTRACE MANUAL INVESTIGATION REPORT".center(80),
        "=" * 80,
        f"  Timestamp   : {ts}",
        f"  Target      : {host}",
        f"  Input Type  : {r['target_type'].upper()}",
        f"  Threat Score: {sev_icon} {severity} ({score}/100)",
        "-" * 80,
        "  HEURISTIC SIGNALS",
    ]
    if hits:
        for h in hits:
            lines.append(f"    > {h}")
    else:
        lines.append("    > No threat signals detected")

    lines += [
        "",
        "  INFRASTRUCTURE",
        f"    > Resolved IPs   : {', '.join(ips) if ips else 'None'}",
        f"    > MX Records     : {', '.join(mx) if mx else 'None'}",
    ]
    if enr.get("mail_configured"):
        lines.append("    > [!] CRITICAL: Active mail infrastructure detected!")
    lines += [
        f"    > TLS Profile    : {tls}",
        f"    > TLS Method     : {method}",
    ]

    # WHOIS block
    lines += ["", "  WHOIS INTELLIGENCE"]
    if whois.get("error") and not whois.get("registrar"):
        lines.append(f"    > Error: {whois.get('error', 'Unknown')}")
    else:
        lines += [
            f"    > Registrar      : {whois.get('registrar', 'Unknown')}",
            f"    > Registrant Org : {whois.get('registrant_org', 'Unknown')}",
            f"    > Country        : {whois.get('registrant_country', 'Unknown')}",
            f"    > Created        : {whois.get('creation_date', 'Unknown')}",
            f"    > Expires        : {whois.get('expiry_date', 'Unknown')}",
            f"    > Domain Age     : {whois.get('domain_age_days', 'Unknown')} days",
            f"    > Name Servers   : {', '.join(whois.get('name_servers', [])) or 'Unknown'}",
            f"    > DNSSEC         : {whois.get('dnssec', 'Unknown')}",
        ]
        if whois.get("risk_flags"):
            lines.append("    > WHOIS Risk Flags:")
            for f in whois["risk_flags"]:
                lines.append(f"        [WARNING] {f}")

    # Shodan / IP Intel blocks
    for sd in shodans:
        ip = sd.get("ip", "Unknown")
        lines += ["", f"  IP INTELLIGENCE — {ip}  [{sd.get('source','').upper()}]"]
        if sd.get("error"):
            lines.append(f"    > {sd['error']}")
        else:
            lines += [
                f"    > ASN / Org      : {sd.get('asn','?')} / {sd.get('org','Unknown')}",
                f"    > ISP            : {sd.get('isp', 'Unknown')}",
                f"    > Country        : {sd.get('country','Unknown')} {sd.get('city','')}",
                f"    > Open Ports     : {', '.join(str(p) for p in sd.get('open_ports',[])[:10]) or 'None'}",
                f"    > Services       : {', '.join(s['product'] for s in sd.get('services',[])[:5]) or 'None'}",
                f"    > CVEs           : {', '.join(sd.get('vulns',[])[:5]) or 'None'}",
                f"    > Hostnames      : {', '.join(sd.get('hostnames',[])[:4]) or 'None'}",
                f"    > Shodan Tags    : {', '.join(sd.get('tags',[])[:5]) or 'None'}",
            ]
            if sd.get("risk_flags"):
                lines.append("    > IP Risk Flags:")
                for f in sd["risk_flags"]:
                    lines.append(f"        [WARNING] {f}")

    if r.get("otx"):
        lines += ["", "  ALIENVAULT OTX INTELLIGENCE"]
        if r["otx"].get("error"):
            lines.append(f"    > Error: {r['otx']['error']}")
        else:
            lines.append(f"    > Pulses Detected: {r['otx'].get('pulses', 0)}")
            tags = r['otx'].get('tags', [])
            lines.append(f"    > OTX Tags       : {', '.join(tags) if tags else 'None'}")
            if r['otx'].get('pulses', 0) > 0:
                lines.append("        [WARNING] Known malicious indicators found on OTX!")

    if r.get("hackertarget") and not r["hackertarget"].get("error"):
        lines += ["", "  HACKERTARGET DNS RECON"]
        for line in r["hackertarget"].get("result", "").splitlines()[:5]:
            lines.append(f"    > {line}")
            
    if r.get("urlhaus") and r["urlhaus"].get("query_status") == "ok":
        lines += ["", "  URLHAUS INTELLIGENCE"]
        lines.append(f"    > Status: KNOWN MALICIOUS")
        lines.append(f"    > URLs: {len(r['urlhaus'].get('urls', []))}")
        lines.append("        [WARNING] Target is listed on abuse.ch URLhaus!")

    lines += ["-" * 80, "  END OF REPORT", "=" * 80]
    return "\n".join(lines)
