"""
CertTrace V3.0 — WebSocket Ingestor (Producer)
Connects to certstream.calidog.io and pushes domains into the asyncio.Queue.
Implements Exponential Backoff reconnection strategy.
"""

import asyncio
import json
import logging
from asyncio import Queue

import websockets
from websockets.exceptions import ConnectionClosed, WebSocketException

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import (
    CERTSTREAM_URL,
    BACKOFF_BASE,
    BACKOFF_CAP,
    BACKOFF_FACTOR,
)
from certtrace.database import log_connection_event

logger = logging.getLogger("certtrace.ingestor")

# ── Live Ingestor ─────────────────────────────────────────────────────────────

async def run_live(queue: Queue) -> None:
    """
    Persistent WebSocket producer.
    Reconnects with exponential backoff on any failure.
    """
    delay = BACKOFF_BASE

    while True:
        try:
            logger.info(f"[WS] Connecting to {CERTSTREAM_URL} …")
            await log_connection_event("CONNECTING", CERTSTREAM_URL)

            async with websockets.connect(
                CERTSTREAM_URL,
                ping_interval=20,
                ping_timeout=10,
                close_timeout=5,
            ) as ws:
                delay = BACKOFF_BASE          # Reset backoff on successful connect
                await log_connection_event("CONNECTED", CERTSTREAM_URL)
                logger.info("[WS] Connection established. Streaming certificates …")

                async for raw_msg in ws:
                    try:
                        _process_message(raw_msg, queue)
                    except Exception as parse_err:
                        logger.debug(f"[WS] Message parse error: {parse_err}")

        except (ConnectionClosed, WebSocketException) as exc:
            await log_connection_event("DISCONNECTED", str(exc))
            logger.warning(f"[WS] Connection lost: {exc}. Retrying in {delay}s …")

        except Exception as exc:
            await log_connection_event("ERROR", str(exc))
            logger.error(f"[WS] Unexpected error: {exc}. Retrying in {delay}s …")

        await asyncio.sleep(delay)
        delay = min(delay * BACKOFF_FACTOR, BACKOFF_CAP)


def _process_message(raw: str, queue: Queue) -> None:
    """Parse a certstream JSON message and push domains onto the queue."""
    msg = json.loads(raw)
    msg_type = msg.get("message_type", "")

    if msg_type != "certificate_update":
        return

    data      = msg.get("data", {})
    leaf_cert = data.get("leaf_cert", {})
    all_domains = leaf_cert.get("all_domains", [])
    issuer_obj  = leaf_cert.get("issuer", {})
    issuer      = (
        issuer_obj.get("O")
        or issuer_obj.get("CN")
        or "Unknown CA"
    )

    for domain in all_domains:
        if not domain or len(domain) < 4:
            continue
        try:
            queue.put_nowait({"domain": domain, "issuer": issuer})
        except asyncio.QueueFull:
            logger.warning("[QUEUE] Buffer full — dropping certificate payload.")

# ── Demo Ingestor ──────────────────────────────────────────────────────────────

async def run_demo(queue: Queue, protected_targets: list = None) -> None:
    """
    Demo WebSocket producer.
    Periodically injects synthetic domains to simulate real-time hits.
    """
    import random
    logger.info("[WS] Started in DEMO mode. Injecting synthetic certificates...")
    
    if not protected_targets:
        protected_targets = ["hdfcbank", "icicibank", "sbi"]

    # Add some noise domains to simulate real stream
    noise_domains = ["example.com", "google.com", "amazon.com", "test.xyz"]

    # Phishing templates
    templates = [
        "{brand}-secure-login.top",
        "{brand}-kyc-update.xyz",
        "verify-{brand}-account.online",
        "login-{brand}.site",
    ]

    issuers = ["Let's Encrypt", "ZeroSSL", "Cloudflare Inc ECC CA-3"]

    while True:
        # Every 2-5 seconds, inject a synthetic hit
        await asyncio.sleep(random.uniform(2, 5))
        
        # 10% chance to inject noise, 90% chance to inject a hit
        if random.random() < 0.10:
            domain = random.choice(noise_domains)
        else:
            brand = random.choice(protected_targets)
            brand_clean = brand.replace(".com", "").replace(".co.in", "")
            domain = random.choice(templates).format(brand=brand_clean)
            
        issuer = random.choice(issuers)
        
        try:
            queue.put_nowait({"domain": domain, "issuer": issuer})
            logger.debug(f"[DEMO] Injected: {domain}")
        except asyncio.QueueFull:
            pass

