"""
CertTrace V3.0 — SQLite3 Database Layer
Thread-safe async operations via aiosqlite.
Two tables:
  - infrastructure_iocs   : main IOC storage
  - connection_log         : producer uptime events
"""

import aiosqlite
import logging
from typing import Optional

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import DB_PATH

logger = logging.getLogger("certtrace.database")

# ── DDL ───────────────────────────────────────────────────────────────────────

DDL_IOCS = """
CREATE TABLE IF NOT EXISTS infrastructure_iocs (
    ioc_id              INTEGER  PRIMARY KEY AUTOINCREMENT,
    timestamp           DATETIME DEFAULT CURRENT_TIMESTAMP,
    phishing_domain     TEXT     NOT NULL,
    certificate_issuer  TEXT,
    threat_score        INTEGER,
    resolved_ips        TEXT,
    mail_servers        TEXT,
    tls_profile         TEXT,
    fingerprint_method  TEXT,
    analyst_verdict     TEXT     DEFAULT 'pending',
    notes               TEXT,
    heuristic_hits      TEXT
);
"""

DDL_CONN_LOG = """
CREATE TABLE IF NOT EXISTS connection_log (
    log_id    INTEGER  PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    event     TEXT,
    detail    TEXT
);
"""

DDL_INDICES = [
    "CREATE INDEX IF NOT EXISTS idx_ioc_score   ON infrastructure_iocs(threat_score);",
    "CREATE INDEX IF NOT EXISTS idx_ioc_verdict ON infrastructure_iocs(analyst_verdict);",
    "CREATE INDEX IF NOT EXISTS idx_ioc_ts      ON infrastructure_iocs(timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_ioc_domain  ON infrastructure_iocs(phishing_domain);",
]

# ── Initialisation ────────────────────────────────────────────────────────────

async def init_db() -> None:
    """Create tables and indices if they don't already exist."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA journal_mode=WAL;")
        await db.execute("PRAGMA synchronous=NORMAL;")
        await db.execute(DDL_IOCS)
        await db.execute(DDL_CONN_LOG)
        for idx in DDL_INDICES:
            await db.execute(idx)
        await db.commit()
    logger.info(f"Database ready at {DB_PATH}")


# ── IOC Writes ────────────────────────────────────────────────────────────────

async def insert_ioc(
    phishing_domain: str,
    certificate_issuer: str,
    threat_score: int,
    resolved_ips: list[str],
    mail_servers: list[str],
    tls_profile: str,
    fingerprint_method: str,
    heuristic_hits: list[str],
) -> int:
    """Insert a new IOC row; returns the new ioc_id."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO infrastructure_iocs
                (phishing_domain, certificate_issuer, threat_score,
                 resolved_ips, mail_servers, tls_profile,
                 fingerprint_method, heuristic_hits)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                phishing_domain,
                certificate_issuer,
                threat_score,
                ", ".join(resolved_ips),
                ", ".join(mail_servers),
                tls_profile,
                fingerprint_method,
                ", ".join(heuristic_hits),
            ),
        )
        await db.commit()
        return cur.lastrowid


async def update_verdict(
    ioc_id: int,
    verdict: str,
    notes: Optional[str] = None,
) -> None:
    """Update analyst_verdict (and optionally notes) for a given IOC."""
    async with aiosqlite.connect(DB_PATH) as db:
        if notes is not None:
            await db.execute(
                "UPDATE infrastructure_iocs SET analyst_verdict=?, notes=? WHERE ioc_id=?",
                (verdict, notes, ioc_id),
            )
        else:
            await db.execute(
                "UPDATE infrastructure_iocs SET analyst_verdict=? WHERE ioc_id=?",
                (verdict, ioc_id),
            )
        await db.commit()


# ── IOC Reads ─────────────────────────────────────────────────────────────────

async def get_ioc(ioc_id: int) -> Optional[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM infrastructure_iocs WHERE ioc_id=?", (ioc_id,)
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_iocs(
    limit: int = 100,
    offset: int = 0,
    min_score: int = 0,
    verdict: Optional[str] = None,
) -> list[dict]:
    clauses = ["threat_score >= ?"]
    params: list = [min_score]
    if verdict:
        clauses.append("analyst_verdict = ?")
        params.append(verdict)
    where = " AND ".join(clauses)
    params += [limit, offset]

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            f"SELECT * FROM infrastructure_iocs WHERE {where} "
            f"ORDER BY timestamp DESC LIMIT ? OFFSET ?",
            params,
        ) as cur:
            rows = await cur.fetchall()
            return [dict(r) for r in rows]


async def get_stats() -> dict:
    """Return aggregated metrics for the dashboard."""
    async with aiosqlite.connect(DB_PATH) as db:
        async def scalar(sql, *args):
            async with db.execute(sql, args) as c:
                row = await c.fetchone()
                return row[0] if row else 0

        total         = await scalar("SELECT COUNT(*) FROM infrastructure_iocs")
        today_total   = await scalar(
            "SELECT COUNT(*) FROM infrastructure_iocs WHERE date(timestamp)=date('now')"
        )
        confirmed     = await scalar(
            "SELECT COUNT(*) FROM infrastructure_iocs WHERE analyst_verdict='confirmed'"
        )
        false_pos     = await scalar(
            "SELECT COUNT(*) FROM infrastructure_iocs WHERE analyst_verdict='false_positive'"
        )
        avg_score     = await scalar(
            "SELECT AVG(threat_score) FROM infrastructure_iocs"
        )
        critical_count = await scalar(
            "SELECT COUNT(*) FROM infrastructure_iocs WHERE threat_score>=80"
        )

        # Score distribution buckets
        async with db.execute(
            """
            SELECT
              CASE
                WHEN threat_score >= 90 THEN '90-100'
                WHEN threat_score >= 80 THEN '80-89'
                WHEN threat_score >= 70 THEN '70-79'
                ELSE '<70'
              END AS bucket,
              COUNT(*) AS cnt
            FROM infrastructure_iocs
            GROUP BY bucket
            """
        ) as cur:
            score_dist = {row[0]: row[1] for row in await cur.fetchall()}

        # CA breakdown
        async with db.execute(
            """
            SELECT certificate_issuer, COUNT(*) as cnt
            FROM infrastructure_iocs
            GROUP BY certificate_issuer
            ORDER BY cnt DESC LIMIT 6
            """
        ) as cur:
            ca_breakdown = [{"issuer": r[0], "count": r[1]} for r in await cur.fetchall()]

        # Hourly volume (last 24h)
        async with db.execute(
            """
            SELECT strftime('%H', timestamp) as hr, COUNT(*) as cnt
            FROM infrastructure_iocs
            WHERE timestamp >= datetime('now', '-24 hours')
            GROUP BY hr ORDER BY hr
            """
        ) as cur:
            hourly = [{"hour": r[0], "count": r[1]} for r in await cur.fetchall()]

        return {
            "total": total,
            "today": today_total,
            "confirmed": confirmed,
            "false_positives": false_pos,
            "avg_score": round(avg_score or 0, 1),
            "critical": critical_count,
            "score_distribution": score_dist,
            "ca_breakdown": ca_breakdown,
            "hourly_volume": hourly,
        }


async def get_topology() -> dict:
    """Return nodes/edges for the network topology graph."""
    nodes = []
    edges = []
    ip_counts: dict[str, int] = {}

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT ioc_id, phishing_domain, resolved_ips, threat_score "
            "FROM infrastructure_iocs ORDER BY timestamp DESC LIMIT 300"
        ) as cur:
            rows = await cur.fetchall()

    for row in rows:
        domain = row["phishing_domain"]
        score  = row["threat_score"] or 0
        ips    = [ip.strip() for ip in (row["resolved_ips"] or "").split(",") if ip.strip()]

        nodes.append({"id": f"d_{row['ioc_id']}", "label": domain,
                       "type": "domain", "score": score})
        for ip in ips:
            ip_counts[ip] = ip_counts.get(ip, 0) + 1
            edges.append({"from": f"ip_{ip}", "to": f"d_{row['ioc_id']}"})

    for ip, count in ip_counts.items():
        nodes.append({"id": f"ip_{ip}", "label": ip,
                       "type": "ip", "connections": count})

    return {"nodes": nodes, "edges": edges}


# ── Connection Log ────────────────────────────────────────────────────────────

async def log_connection_event(event: str, detail: str = "") -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO connection_log (event, detail) VALUES (?, ?)",
            (event, detail),
        )
        await db.commit()


async def get_connection_log(limit: int = 50) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM connection_log ORDER BY timestamp DESC LIMIT ?", (limit,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]
