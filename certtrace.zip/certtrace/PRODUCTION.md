# CertTrace Production Guide

This project is functional in its current form, but production deployment should be handled deliberately.

## Required Environment

- `SHODAN_API_KEY`: set this in the environment before enabling Shodan enrichment.
- `data/`: must be writable for `data/certtrace.db` and `data/tranco_top1m.csv`.
- `logs/`: must be writable for rotating application logs.

Optional runtime settings are centralized in `config.py`:
- `API_HOST`
- `API_PORT`
- `STREAMLIT_PORT`
- `WORKER_COUNT`
- `QUEUE_MAXSIZE`
- `HUNTER_ENABLED`
- `HUNTER_SWEEP_DELAY`
- `HUNTER_BRAND_DELAY`
- `HUNTER_REQUEST_TIMEOUT`

## Deployment Model

Recommended process layout:

1. Run the FastAPI backend with `python main.py` or `python main.py --api-only`.
2. Run the Streamlit dashboard separately with `streamlit run dashboard.py --server.port 8501`.
3. Put both behind a process manager, Windows service, reverse proxy, or container.

## Start Commands

```powershell
pip install -r requirements.txt
python main.py --demo
streamlit run dashboard.py --server.port 8501
```

For live ingestion:

```powershell
python main.py
```

## Operational Checks

- Confirm the SQLite database opens and writes successfully.
- Confirm the dashboard at `http://127.0.0.1:8000` responds.
- Confirm the Streamlit UI at `http://127.0.0.1:8501` loads.
- Confirm logs are created in `logs/certtrace.log`.
- Confirm `check_db.py` prints current IOC statistics.

## Validation Before Release

- Run `python main.py --help`.
- Run `python check_db.py`.
- Run `python -m py_compile` across all Python files.
- Run `ruff check .`.

## Notes

- SQLite is convenient for local and small-scale deployments; use backups.
- If you need stronger reproducibility, pin `requirements.txt` to exact versions after validating the final runtime set.