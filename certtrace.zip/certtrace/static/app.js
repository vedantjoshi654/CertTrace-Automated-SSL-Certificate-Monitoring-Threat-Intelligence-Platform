/**
 * CertTrace V3.0 — Frontend Application Logic
 * WebSocket live feed, Chart.js analytics, vis.js topology, modal/verdict management
 */

'use strict';

// ── State ─────────────────────────────────────────────────────────────────────
const state = {
  ws:            null,
  iocs:          [],          // All received IOC rows (newest first)
  charts:        {},          // Chart.js instances
  topoNetwork:   null,        // vis.js network
  currentIocId:  null,        // ID of IOC open in modal
  wsRetryDelay:  1500,
};

// ── DOM refs ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

// ── WebSocket Connection ──────────────────────────────────────────────────────

function connectWebSocket() {
  const protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  const url = `${protocol}://${location.host}/ws/live`;

  setWsStatus('connecting', 'Connecting…');

  const ws = new WebSocket(url);
  state.ws = ws;

  ws.onopen = () => {
    setWsStatus('connected', 'Live');
    state.wsRetryDelay = 1500;
    refreshStats();
  };

  ws.onmessage = evt => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.type === 'new_ioc') handleNewIoc(msg.data);
    } catch (e) { /* ignore */ }
  };

  ws.onclose = () => {
    setWsStatus('disconnected', `Reconnecting in ${(state.wsRetryDelay/1000).toFixed(0)}s…`);
    setTimeout(connectWebSocket, state.wsRetryDelay);
    state.wsRetryDelay = Math.min(state.wsRetryDelay * 2, 60000);
  };

  ws.onerror = () => ws.close();
}

function setWsStatus(cls, label) {
  const dot   = $('ws-dot');
  const lbl   = $('ws-label');
  dot.className = `ws-dot ${cls}`;
  lbl.textContent = label;
}

// ── IOC Handling ──────────────────────────────────────────────────────────────

function handleNewIoc(ioc) {
  if (!ioc || !ioc.phishing_domain) return;

  // Deduplicate by ioc_id
  if (state.iocs.find(x => x.ioc_id === ioc.ioc_id)) return;

  state.iocs.unshift(ioc);
  if (state.iocs.length > 500) state.iocs.pop();

  injectRow(ioc, true);
  updateCounter();
  hideFeedEmpty();
}

function injectRow(ioc, animate = false) {
  const tbody = $('feed-tbody');
  const tr    = buildRow(ioc, animate);

  if (animate) {
    tbody.insertBefore(tr, tbody.firstChild);
  } else {
    tbody.appendChild(tr);
  }
}

function buildRow(ioc, animate) {
  const tr = document.createElement('tr');
  if (animate) tr.classList.add('new-row');

  const score    = ioc.threat_score || 0;
  const severity = getSeverity(score);
  const ts       = formatTime(ioc.timestamp);

  tr.setAttribute('data-ioc-id', ioc.ioc_id);
  tr.addEventListener('click', () => openModal(ioc.ioc_id));

  tr.innerHTML = `
    <td style="font-family:var(--text-mono);font-size:11px;color:var(--text-muted)">${ts}</td>
    <td><div class="domain-cell" title="${ioc.phishing_domain || ''}">${ioc.defanged_domain || ioc.phishing_domain || '—'}</div></td>
    <td><span class="score-badge ${severity}">${score}</span></td>
    <td style="color:var(--text-secondary);font-size:12px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
      ${escHtml(ioc.certificate_issuer || '—')}
    </td>
    <td>
      <div class="hit-tags">
        ${buildHitTags(ioc.heuristic_hits)}
      </div>
    </td>
    <td>
      <span class="mail-badge ${ioc.mail_configured ? 'active' : 'inactive'}">
        ${ioc.mail_configured ? '✉ ACTIVE' : 'None'}
      </span>
    </td>
    <td><span class="verdict-pill ${ioc.analyst_verdict || 'pending'}">${ioc.analyst_verdict || 'pending'}</span></td>
    <td><button class="detail-btn" onclick="event.stopPropagation();openModal(${ioc.ioc_id})">Report →</button></td>
  `;

  return tr;
}

function buildHitTags(hits) {
  if (!hits || !hits.length) return '<span style="color:var(--text-muted);font-size:11px">—</span>';
  return hits.slice(0, 3).map(h => {
    const short = h.replace(/\(.*?\)/g, '').trim().substring(0, 24);
    return `<span class="hit-tag" title="${escHtml(h)}">${escHtml(short)}</span>`;
  }).join('');
}

// ── Feed Utilities ────────────────────────────────────────────────────────────

function filterFeed() {
  const search   = $('feed-search').value.toLowerCase();
  const minScore = parseInt($('feed-score-filter').value) || 0;

  document.querySelectorAll('#feed-tbody tr').forEach(tr => {
    const id    = parseInt(tr.getAttribute('data-ioc-id'));
    const ioc   = state.iocs.find(x => x.ioc_id === id);
    if (!ioc) return;

    const scoreOk  = (ioc.threat_score || 0) >= minScore;
    const searchOk = !search ||
      (ioc.phishing_domain || '').toLowerCase().includes(search) ||
      (ioc.certificate_issuer || '').toLowerCase().includes(search) ||
      (ioc.resolved_ips || []).join(' ').toLowerCase().includes(search);

    tr.style.display = (scoreOk && searchOk) ? '' : 'none';
  });
}

function clearFeed() {
  $('feed-tbody').innerHTML = '';
  state.iocs = [];
  showFeedEmpty();
  $('counter-total').textContent = '0';
}

function hideFeedEmpty() {
  $('feed-empty').style.display = 'none';
}

function showFeedEmpty() {
  $('feed-empty').style.display = 'flex';
}

function updateCounter() {
  $('counter-total').textContent = state.iocs.length;
}

// ── Tab Navigation ────────────────────────────────────────────────────────────

function showTab(name) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));

  $(`panel-${name}`).classList.add('active');
  $(`tab-${name}`).classList.add('active');

  if (name === 'analytics') loadAnalytics();
  if (name === 'topology')  loadTopology();
  if (name === 'connlog')   loadConnLog();
}

// ── Stats ─────────────────────────────────────────────────────────────────────

async function refreshStats() {
  try {
    const data = await apiFetch('/api/stats');
    $('sv-total').textContent     = data.total     ?? '—';
    $('sv-critical').textContent  = data.critical  ?? '—';
    $('sv-confirmed').textContent = data.confirmed ?? '—';
    $('sv-fp').textContent        = data.false_positives ?? '—';
    $('sv-avg').textContent       = data.avg_score ? `${data.avg_score}` : '—';
    $('counter-total').textContent = data.today ?? state.iocs.length;
  } catch (e) { /* fail silently */ }
}

// ── Analytics Charts ──────────────────────────────────────────────────────────

async function loadAnalytics() {
  try {
    const data = await apiFetch('/api/stats');
    renderScoreDistChart(data.score_distribution || {});
    renderCaChart(data.ca_breakdown || []);
    renderHourlyChart(data.hourly_volume || []);
  } catch (e) {
    console.error('Analytics load failed', e);
  }
}

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      labels: { color: '#8899aa', font: { family: 'Inter', size: 12 } }
    }
  }
};

function renderScoreDistChart(dist) {
  const ctx = document.getElementById('chart-score-dist').getContext('2d');
  if (state.charts.scoreDist) state.charts.scoreDist.destroy();

  const labels = ['90–100', '80–89', '70–79', '<70'];
  const values = labels.map(l => dist[l] || 0);
  const colors = ['rgba(255,51,102,.75)', 'rgba(255,102,51,.75)', 'rgba(255,215,0,.7)', 'rgba(0,230,118,.65)'];

  state.charts.scoreDist = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'IOC Count',
        data: values,
        backgroundColor: colors,
        borderColor: colors.map(c => c.replace(',.7', ',1').replace(',.75', ',1').replace(',.65', ',1')),
        borderWidth: 1,
        borderRadius: 4,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      scales: {
        x: { ticks: { color: '#8899aa' }, grid: { color: 'rgba(0,255,200,0.05)' } },
        y: { ticks: { color: '#8899aa' }, grid: { color: 'rgba(0,255,200,0.05)' } },
      }
    }
  });
}

function renderCaChart(caData) {
  const ctx = document.getElementById('chart-ca-breakdown').getContext('2d');
  if (state.charts.ca) state.charts.ca.destroy();

  const labels  = caData.map(d => d.issuer || 'Unknown');
  const values  = caData.map(d => d.count);
  const colors  = [
    'rgba(0,255,200,.7)', 'rgba(0,112,243,.75)', 'rgba(255,51,102,.7)',
    'rgba(255,153,51,.7)', 'rgba(255,215,0,.65)', 'rgba(100,200,255,.7)',
  ];

  state.charts.ca = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: colors,
        borderColor: 'rgba(13,20,33,0.8)',
        borderWidth: 2,
        hoverOffset: 4,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      cutout: '58%',
    }
  });
}

function renderHourlyChart(hourlyData) {
  const ctx = document.getElementById('chart-hourly').getContext('2d');
  if (state.charts.hourly) state.charts.hourly.destroy();

  const labels = hourlyData.map(d => `${d.hour}:00`);
  const values = hourlyData.map(d => d.count);

  state.charts.hourly = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'IOCs Detected',
        data: values,
        borderColor: 'rgba(0,255,200,0.8)',
        backgroundColor: 'rgba(0,255,200,0.06)',
        borderWidth: 2,
        pointRadius: 3,
        pointBackgroundColor: 'rgba(0,255,200,0.9)',
        fill: true,
        tension: 0.35,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      scales: {
        x: { ticks: { color: '#8899aa' }, grid: { color: 'rgba(0,255,200,0.04)' } },
        y: { ticks: { color: '#8899aa' }, grid: { color: 'rgba(0,255,200,0.04)' } },
      }
    }
  });
}

// ── Topology Graph ────────────────────────────────────────────────────────────

async function loadTopology() {
  try {
    const data = await apiFetch('/api/topology');

    if (!data.nodes || data.nodes.length === 0) {
      $('topo-empty').style.display = 'flex';
      return;
    }

    $('topo-empty').style.display = 'none';
    renderTopology(data);
  } catch (e) {
    console.error('Topology load failed', e);
  }
}

function renderTopology(data) {
  const container = $('topology-graph');

  const nodes = new vis.DataSet(data.nodes.map(n => {
    const isIp = n.type === 'ip';
    const size  = isIp ? Math.min(18 + (n.connections || 1) * 3, 50) : 14;
    return {
      id:    n.id,
      label: n.label,
      color: {
        background: isIp ? '#ff3366' : '#ff7733',
        border:     isIp ? '#ff6699' : '#ffaa55',
        highlight:  { background: isIp ? '#ff6699' : '#ffbb77', border: '#ffffff' },
        hover:      { background: isIp ? '#ff6699' : '#ffaa55', border: '#ffffff' },
      },
      font:  { color: '#e8edf5', size: isIp ? 12 : 10, face: 'JetBrains Mono' },
      size,
      shape: isIp ? 'dot' : 'box',
      borderWidth: 1.5,
    };
  }));

  const edges = new vis.DataSet(data.edges.map((e, i) => ({
    id:    i,
    from:  e.from,
    to:    e.to,
    color: { color: 'rgba(0,255,200,0.3)', highlight: 'rgba(0,255,200,0.8)' },
    width: 1,
    smooth: { type: 'dynamic' },
  })));

  const options = {
    physics: {
      enabled: true,
      barnesHut: {
        gravitationalConstant: -6000,
        springLength: 120,
        springConstant: 0.04,
        damping: 0.12,
      },
      stabilization: { iterations: 150 },
    },
    interaction: {
      hover: true,
      tooltipDelay: 200,
      zoomView: true,
      dragView: true,
    },
    nodes: { borderWidth: 1 },
    edges: { arrows: { to: { enabled: true, scaleFactor: 0.5 } } },
  };

  if (state.topoNetwork) state.topoNetwork.destroy();
  state.topoNetwork = new vis.Network(container, { nodes, edges }, options);
}

function resetGraphView() {
  if (state.topoNetwork) state.topoNetwork.fit({ animation: { duration: 600, easingFunction: 'easeInOutQuad' } });
}

// ── Connection Log ────────────────────────────────────────────────────────────

async function loadConnLog() {
  try {
    const logs = await apiFetch('/api/log?limit=50');
    const tbody = $('connlog-tbody');
    tbody.innerHTML = '';

    if (!logs.length) {
      $('connlog-empty').style.display = 'flex';
      return;
    }

    $('connlog-empty').style.display = 'none';
    logs.forEach(log => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${formatTime(log.timestamp)}</td>
        <td><span class="event-badge event-${log.event}">${log.event}</span></td>
        <td>${escHtml(log.detail || '—')}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error('Conn log load failed', e);
  }
}

// ── IOC Modal ────────────────────────────────────────────────────────────────

async function openModal(iocId) {
  try {
    const ioc = await apiFetch(`/api/iocs/${iocId}`);
    state.currentIocId = iocId;

    // Header
    const severity = getSeverity(ioc.threat_score || 0);
    const badge    = $('modal-badge');
    badge.textContent = severity.toUpperCase();
    badge.className   = `modal-badge ${severity}`;
    $('modal-domain').textContent = ioc.defanged_domain || ioc.phishing_domain;

    // Report
    $('modal-report').textContent = ioc.plaintext_report || '—';

    // Infrastructure
    const infraHtml = buildInfraHtml(ioc);
    $('modal-infra').innerHTML = infraHtml;

    // Notes
    $('modal-notes').value = ioc.notes || '';

    // TLS
    $('modal-tls').innerHTML = `
      <div><span style="color:var(--text-muted)">Profile: </span>${escHtml(ioc.tls_profile || '—')}</div>
      <div><span style="color:var(--text-muted)">Method:  </span>${escHtml(ioc.fingerprint_method || '—')}</div>
    `;

    $('modal-overlay').classList.add('open');
  } catch (e) {
    showToast('Failed to load IOC detail', 'error');
  }
}

function buildInfraHtml(ioc) {
  const ips  = (ioc.resolved_ips  || []).join('<br>') || 'None resolved';
  const mx   = (ioc.mail_servers  || []).join('<br>') || 'None detected';
  const mailClass = ioc.mail_configured ? 'mail-active' : '';

  return `
    <div class="infra-row">
      <span class="infra-label">IPs</span>
      <span class="infra-val">${escHtml(ips)}</span>
    </div>
    <div class="infra-row">
      <span class="infra-label">MX</span>
      <span class="infra-val ${mailClass}">${escHtml(mx)}
        ${ioc.mail_configured ? '<br><span style="font-size:10px;color:#ff3366">⚠️ Active mail infra</span>' : ''}
      </span>
    </div>
    <div class="infra-row">
      <span class="infra-label">Issuer</span>
      <span class="infra-val">${escHtml(ioc.certificate_issuer || '—')}</span>
    </div>
    <div class="infra-row">
      <span class="infra-label">Score</span>
      <span class="infra-val"><span class="score-badge ${getSeverity(ioc.threat_score)}">${ioc.threat_score}/100</span></span>
    </div>
  `;
}

function closeModal(evt) {
  if (evt.target === $('modal-overlay')) closeModalDirect();
}

function closeModalDirect() {
  $('modal-overlay').classList.remove('open');
  state.currentIocId = null;
}

async function setVerdict(verdict) {
  if (!state.currentIocId) return;
  try {
    await apiFetch(`/api/iocs/${state.currentIocId}`, 'PATCH', { verdict });
    showToast(`Verdict set to: ${verdict}`, 'success');
    // Update pill in table
    const tr = document.querySelector(`[data-ioc-id="${state.currentIocId}"]`);
    if (tr) {
      const pill = tr.querySelector('.verdict-pill');
      if (pill) { pill.className = `verdict-pill ${verdict}`; pill.textContent = verdict; }
    }
    refreshStats();
  } catch (e) {
    showToast('Failed to update verdict', 'error');
  }
}

async function saveNotes() {
  if (!state.currentIocId) return;
  const notes = $('modal-notes').value;
  try {
    const verdict = 'pending'; // preserve existing — fetch first
    const cur = await apiFetch(`/api/iocs/${state.currentIocId}`);
    await apiFetch(`/api/iocs/${state.currentIocId}`, 'PATCH', {
      verdict: cur.analyst_verdict || 'pending',
      notes,
    });
    showToast('Notes saved', 'success');
  } catch (e) {
    showToast('Failed to save notes', 'error');
  }
}

// ── API Helper ────────────────────────────────────────────────────────────────

async function apiFetch(url, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`API ${method} ${url} → ${res.status}`);
  return res.json();
}

// ── Utilities ────────────────────────────────────────────────────────────────

function getSeverity(score) {
  if (score >= 90) return 'critical';
  if (score >= 80) return 'high';
  if (score >= 60) return 'medium';
  return 'low';
}

function formatTime(ts) {
  if (!ts) return '—';
  try {
    const d = new Date(ts.includes('Z') || ts.includes('+') ? ts : ts + 'Z');
    return d.toLocaleTimeString('en-GB', { hour12: false }) + ' ' +
           d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  } catch { return ts; }
}

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function showToast(msg, type = '') {
  const t = $('toast');
  t.textContent = msg;
  t.className   = `toast ${type} show`;
  setTimeout(() => { t.className = `toast ${type}`; }, 3000);
}

// ── Init ──────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  connectWebSocket();
  refreshStats();
  setInterval(refreshStats, 30000);
});

// ── Investigator ──────────────────────────────────────────────────────────────

function setTarget(target) {
  $('inv-target').value = target;
  runInvestigation();
}

async function runInvestigation() {
  const target = $('inv-target').value.trim();
  if (!target) return showToast('Please enter a target', 'error');

  const saveToDb = $('inv-save').checked;

  $('inv-loading').style.display = 'flex';
  $('inv-results').style.display = 'none';

  try {
    const res = await apiFetch('/api/investigate', 'POST', { target, save_to_db: saveToDb });

    // Populate Score
    $('inv-score-num').textContent = res.scoring.score;
    $('inv-severity').textContent = res.scoring.severity.toUpperCase();
    $('inv-severity').className = `inv-severity ${res.scoring.severity}`;
    $('inv-result-target').textContent = res.clean_target;

    $('inv-score-hits').innerHTML = res.scoring.hits.length 
      ? res.scoring.hits.map(h => `<div style="color:var(--text-muted);font-size:12px;margin-bottom:4px">› ${escHtml(h)}</div>`).join('')
      : '<div style="color:var(--text-muted);font-size:12px">No specific threat signals detected</div>';

    // Report
    $('inv-report').textContent = res.plaintext_report;

    // Infra
    const ips = (res.enrichment.resolved_ips || []).join(', ') || 'None';
    const mx = (res.enrichment.mail_servers || []).join(', ') || 'None';
    $('inv-infra').innerHTML = `
      <div style="margin-bottom:8px"><strong style="color:var(--text-secondary)">Resolved IPs:</strong> ${escHtml(ips)}</div>
      <div style="margin-bottom:8px"><strong style="color:var(--text-secondary)">MX Records:</strong> ${escHtml(mx)}</div>
      <div style="margin-bottom:8px"><strong style="color:var(--text-secondary)">TLS Profile:</strong> ${escHtml(res.enrichment.tls_profile || 'Unknown')}</div>
    `;

    // WHOIS
    if (res.whois && !res.whois.error) {
      $('inv-whois').innerHTML = `
        <div style="margin-bottom:8px"><strong style="color:var(--text-secondary)">Registrar:</strong> ${escHtml(res.whois.registrar || '—')}</div>
        <div style="margin-bottom:8px"><strong style="color:var(--text-secondary)">Created:</strong> ${escHtml(res.whois.creation_date || '—')}</div>
        <div style="margin-bottom:8px"><strong style="color:var(--text-secondary)">Expires:</strong> ${escHtml(res.whois.expiry_date || '—')}</div>
      `;
    } else {
      $('inv-whois').innerHTML = `<div style="color:var(--text-muted)">WHOIS data unavailable</div>`;
    }

    // Shodan
    const shodanCards = $('inv-shodan-cards');
    shodanCards.innerHTML = '';
    if (res.shodan && res.shodan.length) {
      res.shodan.forEach(s => {
        const div = document.createElement('div');
        div.style.background = 'rgba(255,255,255,0.03)';
        div.style.padding = '12px';
        div.style.borderRadius = '6px';
        div.style.marginBottom = '12px';
        if (s.error) {
          div.innerHTML = `<div style="color:var(--text-muted)">${escHtml(s.ip)}: ${escHtml(s.error)}</div>`;
        } else {
          const ports = (s.open_ports || []).join(', ') || 'None';
          div.innerHTML = `
            <div style="margin-bottom:6px"><strong style="color:var(--text-secondary)">IP:</strong> ${escHtml(s.ip)} [${escHtml(s.source)}]</div>
            <div style="margin-bottom:6px"><strong style="color:var(--text-secondary)">Org:</strong> ${escHtml(s.org || '—')}</div>
            <div style="margin-bottom:6px"><strong style="color:var(--text-secondary)">Location:</strong> ${escHtml(s.city || '')} ${escHtml(s.country || '')}</div>
            <div style="margin-bottom:6px"><strong style="color:var(--text-secondary)">Open Ports:</strong> ${escHtml(ports)}</div>
          `;
        }
        shodanCards.appendChild(div);
      });
    }
    // ── PREMIUM OSINT CARDS ──
    const extrasDiv = document.createElement('div');
    extrasDiv.style.marginTop = '24px';
    extrasDiv.style.display = 'flex';
    extrasDiv.style.flexDirection = 'column';
    extrasDiv.style.gap = '16px';
    
    // AlienVault OTX
    if (res.otx && !res.otx.error) {
      const isMalicious = res.otx.pulses > 0;
      const borderGlow = isMalicious ? 'box-shadow: 0 0 15px rgba(255, 51, 102, 0.4); border: 1px solid rgba(255, 51, 102, 0.6);' : 'border: 1px solid rgba(255, 255, 255, 0.1);';
      const otxHtml = `
        <div style="background: rgba(10, 15, 25, 0.7); backdrop-filter: blur(10px); padding: 16px; border-radius: 8px; ${borderGlow} transition: all 0.3s ease;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 8px;">
            <div style="font-weight: 600; color: #00ffc8; font-family: 'JetBrains Mono', monospace; font-size: 13px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:6px; vertical-align:middle"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>AlienVault OTX
            </div>
            ${isMalicious ? '<span style="background: rgba(255, 51, 102, 0.2); color: #ff3366; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">MALICIOUS PULSES</span>' : '<span style="color: #666; font-size: 11px;">CLEAN</span>'}
          </div>
          <div style="display: grid; grid-template-columns: 1fr; gap: 8px; font-size: 13px;">
            <div><strong style="color:var(--text-secondary)">Pulses Detected:</strong> <span style="color: ${isMalicious ? '#ff3366' : '#fff'}; font-weight: ${isMalicious ? 'bold' : 'normal'}">${res.otx.pulses}</span></div>
            <div><strong style="color:var(--text-secondary)">Threat Tags:</strong> <span style="color: #ccc">${escHtml((res.otx.tags || []).join(', ') || 'None')}</span></div>
          </div>
        </div>
      `;
      extrasDiv.innerHTML += otxHtml;
    }

    // HackerTarget
    if (res.hackertarget && !res.hackertarget.error && res.hackertarget.result) {
      const htHtml = `
        <div style="background: rgba(10, 15, 25, 0.7); backdrop-filter: blur(10px); padding: 16px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.1);">
          <div style="font-weight: 600; color: #00ffc8; font-family: 'JetBrains Mono', monospace; font-size: 13px; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 8px;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:6px; vertical-align:middle"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>HackerTarget Recon
          </div>
          <pre style="margin:0; font-size: 11px; color: #aaa; font-family: 'JetBrains Mono', monospace; white-space: pre-wrap; background: rgba(0,0,0,0.3); padding: 8px; border-radius: 4px; border: 1px solid rgba(255,255,255,0.02); max-height: 150px; overflow-y: auto;">${escHtml(res.hackertarget.result)}</pre>
        </div>
      `;
      extrasDiv.innerHTML += htHtml;
    }

    // URLhaus
    if (res.urlhaus && res.urlhaus.query_status === "ok") {
      const uhHtml = `
        <div style="background: rgba(255, 10, 50, 0.05); backdrop-filter: blur(10px); padding: 16px; border-radius: 8px; border: 1px solid rgba(255, 51, 102, 0.6); box-shadow: 0 0 15px rgba(255, 51, 102, 0.4); animation: pulseRed 2s infinite;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid rgba(255,51,102,0.2); padding-bottom: 8px;">
            <div style="font-weight: 600; color: #ff3366; font-family: 'JetBrains Mono', monospace; font-size: 13px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:6px; vertical-align:middle"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>abuse.ch URLhaus
            </div>
            <span style="background: rgba(255, 51, 102, 0.2); color: #ff3366; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">KNOWN MALWARE HOST</span>
          </div>
          <div style="display: grid; grid-template-columns: 1fr; gap: 8px; font-size: 13px;">
            <div><strong style="color: #ff88aa">Malicious URLs Listed:</strong> <span style="color: #fff; font-weight: bold;">${res.urlhaus.urls ? res.urlhaus.urls.length : 0}</span></div>
            <div style="color:#ff3366; font-size:12px; margin-top:4px;">⚠️ Target is actively distributing malware</div>
          </div>
        </div>
      `;
      // Inject keyframes for pulseRed if not exists
      if (!document.getElementById('pulseRedStyle')) {
          const style = document.createElement('style');
          style.id = 'pulseRedStyle';
          style.innerHTML = `@keyframes pulseRed { 0% { box-shadow: 0 0 10px rgba(255,51,102,0.3); } 50% { box-shadow: 0 0 20px rgba(255,51,102,0.6); } 100% { box-shadow: 0 0 10px rgba(255,51,102,0.3); } }`;
          document.head.appendChild(style);
      }
      extrasDiv.innerHTML += uhHtml;
    }

    if (extrasDiv.innerHTML) {
      shodanCards.appendChild(extrasDiv);
    }

    $('inv-loading').style.display = 'none';
    $('inv-results').style.display = 'block';
    
    if (saveToDb && res.ioc_id) {
        refreshStats();
    }

  } catch (e) {
    $('inv-loading').style.display = 'none';
    showToast('Investigation failed: ' + e.message, 'error');
  }
}

