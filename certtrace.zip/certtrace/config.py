"""
CertTrace V3.0 — Central Configuration
All tuneable constants live here.
"""

import os
from pathlib import Path

# ── Project Paths ─────────────────────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent
DATA_DIR       = BASE_DIR / "data"
DB_PATH        = DATA_DIR / "certtrace.db"
TRANCO_PATH    = DATA_DIR / "tranco_top1m.csv"
TARGETS_FILE   = BASE_DIR / "protected_targets.txt"
LOG_DIR        = BASE_DIR / "logs"
STATIC_DIR     = BASE_DIR / "static"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

# ── Certstream Source ─────────────────────────────────────────────────────────
CERTSTREAM_URL = "wss://certstream.calidog.io/"

# ── Queue / Workers ───────────────────────────────────────────────────────────
QUEUE_MAXSIZE  = 10_000
WORKER_COUNT   = 8

# ── Active OSINT Hunter ───────────────────────────────────────────────────────
HUNTER_ENABLED        = True
HUNTER_SWEEP_DELAY    = 86_400   # seconds between complete brand sweeps
HUNTER_BRAND_DELAY    = 30       # seconds between brand queries (increased to avoid 429)
HUNTER_REQUEST_TIMEOUT = 15      # seconds per crt.sh request

# ── Exponential Backoff ───────────────────────────────────────────────────────
BACKOFF_BASE   = 2          # seconds
BACKOFF_CAP    = 60         # seconds max
BACKOFF_FACTOR = 2

# ── Scoring Thresholds ────────────────────────────────────────────────────────
SCORE_CRITICAL = 80         # Route to enricher
SCORE_MAX      = 100        # Hard cap

# ── Scoring Weights ───────────────────────────────────────────────────────────
WEIGHT_BRAND_IMPERSONATION = 40
WEIGHT_FINANCIAL_KEYWORDS  = 20
WEIGHT_DIGIT_SUBSTITUTION  = 15
WEIGHT_HIGH_RISK_TLD       = 15
WEIGHT_FREE_CA             = 10

# ── Levenshtein Threshold ─────────────────────────────────────────────────────
LEVENSHTEIN_MAX_DISTANCE   = 2

# ── High-Risk TLDs ────────────────────────────────────────────────────────────
HIGH_RISK_TLDS = {
    "xyz", "top", "click", "online", "tk", "ml", "ga", "cf",
    "gq", "pw", "cc", "ws", "biz", "info", "site", "live",
    "icu", "vip", "monster", "cyou", "bond", "cfd",
}

# ── Financial Keywords (regex alternation) ────────────────────────────────────
FINANCIAL_KEYWORD_PATTERN = (
    r"kyc|verify|verif|login|auth|secure|account|update|"
    r"confirm|banking|wallet|payment|transfer|otp|pin|"
    r"credential|helpdesk|support|alert|notice|block"
)

# ── Digit Substitution / Homoglyph Patterns ───────────────────────────────────
HOMOGLYPH_PATTERN = (
    r"0nline|paypa1|1nvoice|arnazon|g00gle|micros0ft|"
    r"netfl1x|app1e|faceb00k|tw1tter|1nstagram|amaz0n|"
    r"ba[0o]k|[il1][il1][il1]|rn(?=[a-z])"     # rn → m lookalike
)

# ── Free Certificate Authorities ─────────────────────────────────────────────
FREE_CA_PATTERNS = {
    "let's encrypt", "letsencrypt", "zerossl", "buypass",
    "ssl.com", "actalis", "e1", "e2", "r3", "r10", "r11",
}

# ── OSINT / External APIs ────────────────────────────────────────────────────
# Set SHODAN_API_KEY env var or paste your key here
SHODAN_API_KEY        = os.environ.get("SHODAN_API_KEY", "YOUR_SHODAN_API_KEY")
NEWLY_REGISTERED_DAYS = 30      # flag domains younger than this
WHOIS_ENABLED         = True
SHODAN_ENABLED        = True

# ── FastAPI / Dashboard ───────────────────────────────────────────────────────
API_HOST       = "127.0.0.1"
API_PORT       = 8080
STREAMLIT_PORT = 8501

# ── Tranco Refresh ────────────────────────────────────────────────────────────
TRANCO_URL     = "https://tranco-list.eu/top-1m.csv.zip"

# ── Demo Mode Synthetic Payloads ──────────────────────────────────────────────
DEMO_CERTS = [
    # High-fidelity threats (score ≥ 80)
    {"domain": "sbi-kyc-verify.xyz",         "issuer": "Let's Encrypt"},
    {"domain": "hdfcbank-secure-login.top",   "issuer": "ZeroSSL"},
    {"domain": "icici-account-update.online", "issuer": "Let's Encrypt"},
    {"domain": "paypa1-auth-confirm.xyz",     "issuer": "Let's Encrypt"},
    {"domain": "amaz0n-wallet-verify.click",  "issuer": "ZeroSSL"},
    {"domain": "sbi-netbanking-otp.live",     "issuer": "Let's Encrypt"},
    {"domain": "hdfcbnk-secure.xyz",          "issuer": "Let's Encrypt"},
    {"domain": "icicibank-kyc-alert.top",     "issuer": "ZeroSSL"},
    {"domain": "axisbank-login-verify.site",  "issuer": "Let's Encrypt"},
    {"domain": "kotakbank-auth.online",       "issuer": "Let's Encrypt"},
    # Borderline (score 50–79, should NOT trigger enrichment)
    {"domain": "mybankinfo.net",              "issuer": "DigiCert"},
    {"domain": "secure-payments.io",          "issuer": "Comodo"},
    {"domain": "loginportal.org",             "issuer": "GlobalSign"},
    # Legitimate (should be filtered by allowlist / protected check)
    {"domain": "hdfcbank.com",               "issuer": "DigiCert"},
    {"domain": "google.com",                  "issuer": "GTS CA 1C3"},
]
