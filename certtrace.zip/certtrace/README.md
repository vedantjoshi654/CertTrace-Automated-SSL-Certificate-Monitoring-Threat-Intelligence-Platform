# 🔐 CertTrace V3.0 — Real-time SSL Threat Intelligence Platform

> Monitor the global SSL/TLS certificate transparency stream in real-time. Automatically detect phishing domains impersonating your protected brands, enrich IOCs with DNS/MX/TLS data, and investigate via a premium dual dashboard.

---

## Architecture

```
certstream.calidog.io (WebSockets)
        │
        ▼
  [Ingestor / Producer]         ← Exponential backoff reconnect
        │
        ▼
  asyncio.Queue(maxsize=10000)  ← OOM protection
        │
        ▼
  [Worker Pool × 8]             ← asyncio.TaskGroup, strict error isolation
        │
  ┌─────┴──────────────────────────────────────┐
  │     4-Step Pipeline:                        │
  │  1. tldextract normalisation                │
  │  2. Protected Brand exact-match drop        │
  │  3. Tranco Top 1M allowlist drop            │
  │  4. Heuristic Scoring (max 100)             │
  └─────────────────────┬──────────────────────┘
                        │  score ≥ 80
                        ▼
              [Active Enrichment]
              ├─ DNS A/AAAA → Resolved IPs
              ├─ MX records → Mail infra detection
              └─ TLS fingerprint (JA4+ → pure-Python fallback)
                        │
                        ▼
              [SQLite3: certtrace.db]
                        │
              ┌─────────┴──────────┐
              ▼                    ▼
     FastAPI REST+WS       Streamlit Dashboard
     Premium HTML UI       Plotly Analytics
     (port 8000)           (port 8501)
```

---

## Quick Start

### 1. Install dependencies
```powershell
pip install -r requirements.txt
```

### 2. Demo mode (no internet required)
```powershell
python main.py --demo
```
Then open: **http://127.0.0.1:8000** (HTML dashboard)

### 3. Streamlit analytics dashboard (separate terminal)
```powershell
streamlit run dashboard.py --server.port 8501
```
Then open: **http://127.0.0.1:8501**

### 4. Live mode (requires internet)
```powershell
python main.py
```

By default, live mode now also starts the `crt.sh` OSINT hunter producer, which
feeds historical brand-matching domains into the same worker queue. Disable it
with `--no-hunter` if you only want the CertStream feed.

Hunter timing defaults are configurable in `config.py`:
- `HUNTER_SWEEP_DELAY` — delay between full brand sweeps
- `HUNTER_BRAND_DELAY` — delay between individual brand queries
- `HUNTER_REQUEST_TIMEOUT` — per-request timeout for crt.sh queries

### 5. Refresh Tranco allowlist
```powershell
python main.py --refresh-allowlist
```

---

## Production Notes

For a production deployment, review `PRODUCTION.md` before launching the service.

At minimum, set `SHODAN_API_KEY` in the environment and ensure these paths are writable:
- `data/` for SQLite storage and allowlist refreshes
- `logs/` for rotating application logs

Recommended production start sequence:
1. Launch the FastAPI backend with `python main.py` or `python main.py --api-only`
2. Launch the Streamlit dashboard in a separate process with `streamlit run dashboard.py --server.port 8501`
3. Put both behind a process manager, service wrapper, or container

---

## CLI Reference

| Flag | Description |
|---|---|
| *(no flags)* | Live mode — connect to certstream.calidog.io |
| `--demo` | Demo mode — synthetic certs (offline testing) |
| `--refresh-allowlist` | Download fresh Tranco Top 1M list |
| `--api-only` | Start FastAPI server only (no ingestor) |
| `--no-api` | Run pipeline only (no web server) |
| `--hunter / --no-hunter` | Enable or disable the crt.sh OSINT hunter producer |
| `--workers N` | Override consumer worker count (default: 8) |
| `-v / --verbose` | Enable DEBUG logging |

---

## Scoring Rubric

| Signal | Detection Method | Weight |
|---|---|---|
| Brand Impersonation | TheFuzz Levenshtein ≤ 2 from protected list | +40 |
| Financial Keywords | Boolean regex (kyc, verify, login, auth…) | +20 |
| Digit Substitution | Homoglyph regex (paypa1, 0nline…) | +15 |
| High-Risk TLD | .xyz .top .click .online .tk … | +15 |
| Free CA | Let's Encrypt / ZeroSSL | +10 |

**Max score: 100. Threshold for enrichment: ≥ 80.**

---

## File Structure

```
certtrace/
├── main.py                  CLI entrypoint
├── api.py                   FastAPI REST + WebSocket backend
├── dashboard.py             Streamlit analytics dashboard
├── config.py                All tuneable constants
├── requirements.txt         Python dependencies
├── protected_targets.txt    Your monitored brand domains
├── certtrace/
│   ├── ingestor.py          WebSocket producer (certstream)
│   ├── worker.py            asyncio.TaskGroup consumer pool
│   ├── scorer.py            Heuristic scoring engine
│   ├── enricher.py          DNS/MX/TLS enrichment
│   ├── database.py          SQLite3 async CRUD layer
│   ├── reporter.py          IOC report formatter
│   └── allowlist.py         Tranco Top 1M manager
├── static/
│   ├── index.html           Premium HTML dashboard
│   ├── style.css            Dark cybersecurity CSS
│   └── app.js               Frontend JS (WS + Charts + Topology)
└── data/
    ├── certtrace.db          SQLite database (auto-created)
    └── tranco_top1m.csv      Tranco list (auto-downloaded)
```

---

## Dashboards

### HTML Dashboard (http://127.0.0.1:8000)
- **Live Feed** — Real-time WebSocket-driven IOC table
- **Topology** — vis.js network graph (IP hubs → domain leaves)
- **Analytics** — Chart.js score distribution, CA split, hourly volume
- **Conn Log** — WebSocket connection event log
- **IOC Modal** — Full IOC Analysis Report + analyst verdict controls

### Streamlit Dashboard (http://127.0.0.1:8501)
- **Live IOC Feed** — Styled DataFrame with quick verdict update
- **IOC Detail** — Dropdown selector + full plaintext report
- **Topology Graph** — Plotly force-directed graph
- **Analytics** — Area chart, pie chart, bar chart
- **Conn Log** — Connection event table

---

## Ethics & Legal

This tool operates under a **read-only, non-intrusive paradigm**:
- Ingests only **public CT log broadcast data** (public record by design)
- DNS lookups are **passive read-only queries**
- TLS profiling sends only a **ClientHello handshake** — no HTTP/payload interaction
- Zero offensive automation, takedowns, or external reporting
