"""
CertTrace V3.0 — Streamlit Analyst Dashboard
Complementary deep-dive analytics view running alongside the HTML dashboard.
Run with: streamlit run dashboard.py
"""

import asyncio
import sys
import os
from datetime import datetime

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from streamlit_autorefresh import st_autorefresh

sys.path.insert(0, os.path.dirname(__file__))
from certtrace.database import init_db, get_iocs, get_stats, get_topology, get_connection_log, update_verdict
from certtrace.reporter import format_structured

# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="CertTrace V3.0 | Analyst Dashboard",
    page_icon="🔐",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS injection ───────────────────────────────────────────────────────

st.markdown("""
<style>
  /* Hide default Streamlit chrome */
  #MainMenu, footer, header { visibility: hidden; }
  .block-container { padding-top: 1rem; }

  /* Dark palette overrides */
  :root {
    --accent: #00ffc8;
    --danger: #ff3366;
    --warn:   #ff9933;
    --ok:     #00e676;
  }

  /* Score badge styling */
  .score-critical { color: #ff3366; font-weight: 700; }
  .score-high     { color: #ff6633; font-weight: 700; }
  .score-medium   { color: #ffd700; font-weight: 700; }
  .score-low      { color: #00e676; font-weight: 600; }

  /* Report box */
  .ioc-report-box {
    background: #0a0f1a;
    border: 1px solid rgba(0,255,200,0.2);
    border-radius: 8px;
    padding: 16px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    color: #00ffc8;
    line-height: 1.65;
    white-space: pre;
    overflow-x: auto;
  }

  /* Header brand */
  .brand-header {
    font-size: 28px;
    font-weight: 800;
    background: linear-gradient(135deg, #00ffc8, #0070f3);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0;
  }

  /* Metric card tweak */
  [data-testid="metric-container"] {
    background: #111827;
    border: 1px solid rgba(0,255,200,0.1);
    border-radius: 10px;
    padding: 14px;
  }
</style>
""", unsafe_allow_html=True)

# ── Auto-refresh every 15s ────────────────────────────────────────────────────
st_autorefresh(interval=15000, key="autorefresh")

# ── Async helpers ─────────────────────────────────────────────────────────────

def run_async(coro):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        return loop.run_until_complete(coro)
    except Exception:
        return asyncio.run(coro)


@st.cache_data(ttl=10)
def load_stats():
    return run_async(get_stats())


@st.cache_data(ttl=10)
def load_iocs(limit=200, min_score=0, verdict=None):
    return run_async(get_iocs(limit=limit, min_score=min_score, verdict=verdict))


@st.cache_data(ttl=30)
def load_topology():
    return run_async(get_topology())


@st.cache_data(ttl=10)
def load_conn_log():
    return run_async(get_connection_log(limit=40))

# ── DB Init ───────────────────────────────────────────────────────────────────
run_async(init_db())

# ════════════════════════════════════════════════════════════════════════════════
#  SIDEBAR
# ════════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown('<div class="brand-header">🔐 CertTrace</div>', unsafe_allow_html=True)
    st.caption("V3.0 — Real-time SSL Threat Intelligence")
    st.divider()

    st.subheader("🔧 Filters")
    min_score_filter = st.slider("Min Threat Score", 0, 100, 80, step=5)
    verdict_filter   = st.selectbox("Analyst Verdict", ["All", "pending", "confirmed", "false_positive"])
    limit_filter     = st.slider("Max Rows", 50, 500, 150, step=50)

    st.divider()
    st.subheader("📋 Pages")
    page = st.radio(
        "Navigate to",
        ["📡 Live IOC Feed", "🔎 IOC Detail", "🕸 Topology Graph", "📊 Analytics", "📜 Conn Log"],
        label_visibility="collapsed",
    )

    st.divider()
    st.caption(f"🕐 Last refresh: {datetime.now().strftime('%H:%M:%S')}")

# ── Load data ─────────────────────────────────────────────────────────────────

stats      = load_stats()
ioc_rows   = load_iocs(
    limit=limit_filter,
    min_score=min_score_filter,
    verdict=None if verdict_filter == "All" else verdict_filter,
)

# ════════════════════════════════════════════════════════════════════════════════
#  TOP METRICS
# ════════════════════════════════════════════════════════════════════════════════

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total IOCs",       f"{stats.get('total',0):,}")
c2.metric("Today",            f"{stats.get('today',0):,}")
c3.metric("🚨 Critical ≥90",  f"{stats.get('critical',0):,}", delta=None)
c4.metric("✅ Confirmed",      f"{stats.get('confirmed',0):,}")
c5.metric("Avg Score",        f"{stats.get('avg_score',0):.1f}/100")

st.divider()

# ════════════════════════════════════════════════════════════════════════════════
#  PAGE: LIVE IOC FEED
# ════════════════════════════════════════════════════════════════════════════════

if "📡 Live IOC Feed" in page:
    st.subheader("📡 Real-Time IOC Feed")

    if not ioc_rows:
        st.info("No IOCs matched your filters. Try lowering the min score or running `python main.py --demo`.")
    else:
        df = pd.DataFrame(ioc_rows)

        # Colour score column
        def colour_score(val):
            if val >= 90:
                return 'color: #ff3366; font-weight: bold'
            if val >= 80:
                return 'color: #ff6633; font-weight: bold'
            if val >= 60:
                return 'color: #ffd700'
            return 'color: #00e676'

        display_cols = [
            "ioc_id", "timestamp", "phishing_domain", "threat_score",
            "certificate_issuer", "mail_configured", "analyst_verdict",
        ]
        existing_cols = [c for c in display_cols if c in df.columns]

        styled = (
            df[existing_cols]
            .rename(columns={
                "ioc_id": "ID", "timestamp": "Time",
                "phishing_domain": "Domain", "threat_score": "Score",
                "certificate_issuer": "Issuer", "mail_configured": "Mail Active",
                "analyst_verdict": "Verdict",
            })
            .style.map(colour_score, subset=["Score"])
        )

        st.dataframe(styled, width="stretch", height=480)

        # Quick verdict update
        st.subheader("⚡ Quick Verdict Update")
        col_a, col_b, col_c = st.columns(3)
        sel_id  = col_a.number_input("IOC ID", min_value=1, step=1)
        new_ver = col_b.selectbox("New Verdict", ["confirmed", "false_positive", "pending"])
        if col_c.button("✅ Apply", width="stretch"):
            run_async(update_verdict(int(sel_id), new_ver))
            st.success(f"IOC #{sel_id} → {new_ver}")
            st.cache_data.clear()
            st.rerun()

# ════════════════════════════════════════════════════════════════════════════════
#  PAGE: IOC DETAIL
# ════════════════════════════════════════════════════════════════════════════════

elif "🔎 IOC Detail" in page:
    st.subheader("🔎 IOC Detail Viewer")

    ioc_ids = [r["ioc_id"] for r in ioc_rows] if ioc_rows else []
    if not ioc_ids:
        st.warning("No IOCs available. Adjust your filters.")
    else:
        sel = st.selectbox(
            "Select IOC",
            ioc_ids,
            format_func=lambda i: next(
                (f"#{i} — {r['phishing_domain']} (score {r['threat_score']})"
                 for r in ioc_rows if r["ioc_id"] == i), str(i)
            ),
        )
        chosen = next((r for r in ioc_rows if r["ioc_id"] == sel), None)
        if chosen:
            structured = format_structured(chosen)
            report_txt = structured["plaintext_report"]

            col_rep, col_meta = st.columns([2, 1])
            with col_rep:
                st.markdown("**IOC Analysis Report**")
                st.markdown(
                    f'<div class="ioc-report-box">{report_txt}</div>',
                    unsafe_allow_html=True,
                )

            with col_meta:
                st.markdown("**Heuristic Hits**")
                for hit in structured.get("heuristic_hits", []):
                    st.markdown(f"- `{hit}`")

                st.divider()
                st.markdown("**Analyst Verdict**")
                new_v = st.radio(
                    "Set verdict",
                    ["confirmed", "false_positive", "pending"],
                    index=["confirmed","false_positive","pending"].index(
                        chosen.get("analyst_verdict","pending")
                    ),
                    horizontal=True,
                    key="detail_verdict",
                )
                notes_val = st.text_area("Notes", value=chosen.get("notes") or "")
                if st.button("💾 Save", key="btn_save_detail"):
                    run_async(update_verdict(sel, new_v, notes_val))
                    st.success("Saved!")
                    st.cache_data.clear()
                    st.rerun()

# ════════════════════════════════════════════════════════════════════════════════
#  PAGE: TOPOLOGY GRAPH
# ════════════════════════════════════════════════════════════════════════════════

elif "🕸 Topology Graph" in page:
    st.subheader("🕸 Network Topology — Phishing Infrastructure")

    topo = load_topology()
    nodes_raw = topo.get("nodes", [])
    edges_raw = topo.get("edges", [])

    if not nodes_raw:
        st.info("No topology data yet. IOCs with resolved IPs will appear here.")
    else:
        # Build Plotly network graph
        ip_nodes     = [n for n in nodes_raw if n["type"] == "ip"]
        domain_nodes = [n for n in nodes_raw if n["type"] == "domain"]

        node_x, node_y, node_text, node_color, node_size = [], [], [], [], []

        import math
        import random
        random.seed(42)

        pos = {}
        for i, n in enumerate(ip_nodes):
            angle = (2 * math.pi * i) / max(len(ip_nodes), 1)
            pos[n["id"]] = (math.cos(angle) * 2, math.sin(angle) * 2)

        for i, n in enumerate(domain_nodes):
            pos[n["id"]] = (random.uniform(-3.5, 3.5), random.uniform(-3.5, 3.5))

        for n in nodes_raw:
            x, y = pos.get(n["id"], (0, 0))
            node_x.append(x)
            node_y.append(y)
            node_text.append(n["label"])
            if n["type"] == "ip":
                node_color.append("rgba(255,51,102,0.85)")
                node_size.append(min(14 + n.get("connections",1)*2, 40))
            else:
                node_color.append("rgba(255,153,51,0.85)")
                node_size.append(12)

        edge_x, edge_y = [], []
        for e in edges_raw:
            x0, y0 = pos.get(e["from"], (0,0))
            x1, y1 = pos.get(e["to"],   (0,0))
            edge_x += [x0, x1, None]
            edge_y += [y0, y1, None]

        edge_trace = go.Scatter(
            x=edge_x, y=edge_y,
            mode='lines',
            line=dict(width=1, color='rgba(0,255,200,0.25)'),
            hoverinfo='none',
        )
        node_trace = go.Scatter(
            x=node_x, y=node_y,
            mode='markers+text',
            text=node_text,
            textposition='top center',
            textfont=dict(color='#ccddee', size=9),
            marker=dict(
                size=node_size,
                color=node_color,
                line=dict(width=1, color='rgba(0,255,200,0.3)'),
            ),
            hoverinfo='text',
        )

        fig = go.Figure(
            data=[edge_trace, node_trace],
            layout=go.Layout(
                paper_bgcolor='#0d1421',
                plot_bgcolor='#0d1421',
                showlegend=False,
                margin=dict(l=0, r=0, t=10, b=0),
                height=520,
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            )
        )
        st.plotly_chart(fig, width="stretch")

        col_ip, col_dom = st.columns(2)
        col_ip.metric("IP Hub Nodes",    len(ip_nodes))
        col_dom.metric("Domain Leaves",  len(domain_nodes))

# ════════════════════════════════════════════════════════════════════════════════
#  PAGE: ANALYTICS
# ════════════════════════════════════════════════════════════════════════════════

elif "📊 Analytics" in page:
    st.subheader("📊 Detection Analytics")

    col_a, col_b = st.columns(2)

    # Score distribution
    score_dist = stats.get("score_distribution", {})
    if score_dist:
        df_s = pd.DataFrame(
            [(k, v) for k, v in score_dist.items()],
            columns=["Bucket", "Count"]
        )
        fig_s = px.bar(
            df_s, x="Bucket", y="Count",
            color="Count",
            color_continuous_scale=["#00e676", "#ffd700", "#ff6633", "#ff3366"],
            title="Score Distribution",
            template="plotly_dark",
        )
        fig_s.update_layout(paper_bgcolor="#111827", plot_bgcolor="#111827")
        col_a.plotly_chart(fig_s, width="stretch")

    # CA breakdown
    ca_data = stats.get("ca_breakdown", [])
    if ca_data:
        df_ca = pd.DataFrame(ca_data)
        fig_ca = px.pie(
            df_ca, names="issuer", values="count",
            title="Certificate Authority Split",
            hole=0.5,
            template="plotly_dark",
            color_discrete_sequence=px.colors.sequential.Teal,
        )
        fig_ca.update_layout(paper_bgcolor="#111827")
        col_b.plotly_chart(fig_ca, width="stretch")

    # Hourly volume
    hourly = stats.get("hourly_volume", [])
    if hourly:
        df_h = pd.DataFrame(hourly)
        df_h["hour"] = df_h["hour"].astype(str) + ":00"
        fig_h = px.area(
            df_h, x="hour", y="count",
            title="Hourly Detection Volume (Last 24h)",
            template="plotly_dark",
            color_discrete_sequence=["#00ffc8"],
        )
        fig_h.update_layout(paper_bgcolor="#111827", plot_bgcolor="#111827")
        st.plotly_chart(fig_h, width="stretch")

    if not score_dist and not ca_data and not hourly:
        st.info("Analytics data will populate as IOCs are detected. Run with `--demo` to seed data.")

# ════════════════════════════════════════════════════════════════════════════════
#  PAGE: CONNECTION LOG
# ════════════════════════════════════════════════════════════════════════════════

elif "📜 Conn Log" in page:
    st.subheader("📜 WebSocket Connection Log")

    logs = load_conn_log()
    if logs:
        df_log = pd.DataFrame(logs)
        st.dataframe(df_log[["timestamp","event","detail"]], width="stretch", height=400)
    else:
        st.info("No connection events yet. Start the ingestor to see activity here.")
