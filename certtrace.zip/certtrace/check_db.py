import sqlite3
import os
import sys

db = os.path.join(os.path.dirname(__file__), 'data', 'certtrace.db')
if not os.path.exists(db):
    print(f'DB not found: {db}')
    sys.exit(0)

con = sqlite3.connect(db)
con.row_factory = sqlite3.Row

total = con.execute('SELECT COUNT(*) FROM infrastructure_iocs').fetchone()[0]
today = con.execute("SELECT COUNT(*) FROM infrastructure_iocs WHERE date(timestamp)=date('now')").fetchone()[0]
avg   = con.execute('SELECT ROUND(AVG(threat_score),1) FROM infrastructure_iocs').fetchone()[0]
crit  = con.execute('SELECT COUNT(*) FROM infrastructure_iocs WHERE threat_score>=90').fetchone()[0]
high  = con.execute('SELECT COUNT(*) FROM infrastructure_iocs WHERE threat_score>=80').fetchone()[0]

print('=== DATABASE STATUS ===')
print(f'  Total IOCs : {total}')
print(f'  Today      : {today}')
print(f'  Avg Score  : {avg or 0}')
print(f'  Critical   : {crit}  (score>=90)')
print(f'  High       : {high}  (score>=80)')
print()

rows = con.execute(
    'SELECT ioc_id, threat_score, phishing_domain, certificate_issuer, '
    'mail_servers, analyst_verdict, heuristic_hits '
    'FROM infrastructure_iocs ORDER BY ioc_id DESC LIMIT 15'
).fetchall()

print('=== LATEST IOCs ===')
for r in rows:
    mx   = '[MX!]' if r['mail_servers'] else '     '
    hits = (r['heuristic_hits'] or '').split(',')[0].strip()[:30]
    print(f"  #{r['ioc_id']:<4} [{r['threat_score']:>3}] {mx} {r['phishing_domain']:<42} verdict={r['analyst_verdict']}")

print()
dist = con.execute(
    "SELECT CASE WHEN threat_score>=90 THEN '90-100' "
    "WHEN threat_score>=80 THEN '80-89' ELSE 'other' END b,"
    "COUNT(*) c FROM infrastructure_iocs GROUP BY b ORDER BY b DESC"
).fetchall()
print('=== SCORE DISTRIBUTION ===')
for d in dist:
    print(f'  {d["b"]:>8} : {d["c"]:>4} IOCs')

con.close()
