"""
CertTrace V3.0 — FastAPI REST + WebSocket Backend
Serves:
  GET  /                  → Premium HTML dashboard (static/index.html)
  GET  /api/iocs          → Paginated IOC list
  GET  /api/iocs/{id}     → Single IOC with full report
  PATCH /api/iocs/{id}    → Update verdict / notes
  GET  /api/stats         → Aggregated metrics
  GET  /api/topology      → Graph nodes + edges
  GET  /api/log           → Connection log
  WS   /ws/live           → Real-time IOC push to HTML dashboard
"""

import json
import logging
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from certtrace.database import (
    init_db, get_iocs, get_ioc, update_verdict,
    get_stats, get_topology, get_connection_log,
)
from certtrace.reporter    import format_structured
from certtrace.investigator import investigate as run_investigation, configure as configure_investigator

logger = logging.getLogger("certtrace.api")

# ── FastAPI App ───────────────────────────────────────────────────────────────

app = FastAPI(title="CertTrace V3.0", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = Path(__file__).parent / "static"

# Mount static directory for CSS/JS assets
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# ── WebSocket Manager ─────────────────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)
        logger.info(f"[WS] Client connected. Total: {len(self.active)}")

    def disconnect(self, ws: WebSocket):
        self.active = [c for c in self.active if c is not ws]
        logger.info(f"[WS] Client disconnected. Total: {len(self.active)}")

    async def broadcast(self, payload: dict):
        if not self.active:
            return
        msg = json.dumps(payload)
        dead = []
        for ws in self.active:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


manager = ConnectionManager()


async def broadcast_ioc(payload: dict):
    """Called by the worker pool to push new IOCs to all connected browsers."""
    await manager.broadcast({"type": "new_ioc", "data": payload})


# ── Startup ────────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def on_startup():
    await init_db()
    # Wire investigator's protected target list
    try:
        from config import TARGETS_FILE
        targets = []
        if TARGETS_FILE.exists():
            with open(TARGETS_FILE) as f:
                targets = [line.strip().lower() for line in f if line.strip() and not line.startswith('#')]
        configure_investigator(targets)
    except Exception as e:
        logger.warning(f"Could not load targets for investigator: {e}")
    logger.info("CertTrace API ready.")


# ── HTML Dashboard ─────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_dashboard():
    index = STATIC_DIR / "index.html"
    if index.exists():
        return HTMLResponse(content=index.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>CertTrace V3.0 — Dashboard Not Found</h1>", status_code=404)


# ── WebSocket Endpoint ─────────────────────────────────────────────────────────

@app.websocket("/ws/live")
async def ws_live(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send last 20 IOCs on connect so the UI pre-populates
        iocs = await get_iocs(limit=20)
        for row in reversed(iocs):
            structured = format_structured(row)
            await websocket.send_text(json.dumps({"type": "new_ioc", "data": structured}))

        while True:
            # Keep connection alive — just consume any pings from client
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception:
        manager.disconnect(websocket)


# ── REST Endpoints ─────────────────────────────────────────────────────────────

@app.get("/api/iocs")
async def api_get_iocs(
    limit:     int = 100,
    offset:    int = 0,
    min_score: int = 0,
    verdict:   Optional[str] = None,
):
    rows = await get_iocs(limit=limit, offset=offset, min_score=min_score, verdict=verdict)
    return [format_structured(r) for r in rows]


@app.get("/api/iocs/{ioc_id}")
async def api_get_ioc(ioc_id: int):
    row = await get_ioc(ioc_id)
    if not row:
        raise HTTPException(status_code=404, detail="IOC not found")
    return format_structured(row)


class VerdictUpdate(BaseModel):
    verdict: str       # "confirmed" | "false_positive" | "pending"
    notes:   Optional[str] = None


@app.patch("/api/iocs/{ioc_id}")
async def api_update_verdict(ioc_id: int, body: VerdictUpdate):
    row = await get_ioc(ioc_id)
    if not row:
        raise HTTPException(status_code=404, detail="IOC not found")
    await update_verdict(ioc_id, body.verdict, body.notes)
    return {"status": "updated", "ioc_id": ioc_id}


@app.get("/api/stats")
async def api_stats():
    return await get_stats()


@app.get("/api/topology")
async def api_topology():
    return await get_topology()


@app.get("/api/log")
async def api_connection_log(limit: int = 50):
    return await get_connection_log(limit=limit)


# ── Manual Investigation Endpoint ──────────────────────────────────────────────

class InvestigateRequest(BaseModel):
    target:     str
    save_to_db: bool = True


@app.post("/api/investigate")
async def api_investigate(body: InvestigateRequest):
    """
    Submit any domain / URL / IP for full OSINT investigation:
    scoring + DNS/MX/TLS + WHOIS + Shodan/ipwhois
    """
    if not body.target or len(body.target.strip()) < 3:
        raise HTTPException(status_code=400, detail="Target must be at least 3 characters")
    if len(body.target) > 512:
        raise HTTPException(status_code=400, detail="Target too long")

    result = await run_investigation(
        raw_input   = body.target.strip(),
        save_to_db  = body.save_to_db,
        broadcast_cb= broadcast_ioc,
    )
    return result
